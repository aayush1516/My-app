"use client"

import { useState } from "react"
import { ArrowLeft, Star, Play, Plus, Share, Heart, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { VideoPlayer } from "@/components/video-player"

const seriesData = {
  id: 3,
  title: "Crime Stories",
  rating: 9.1,
  year: 2024,
  genre: ["Crime", "Drama", "Thriller"],
  director: "Anurag Kashyap",
  cast: ["Nawazuddin Siddiqui", "Pankaj Tripathi", "Richa Chadha"],
  image: "/placeholder.svg?height=400&width=300&text=Crime+Stories",
  backdrop: "/placeholder.svg?height=400&width=800&text=Crime+Stories+Backdrop",
  description:
    "A gripping crime thriller series that follows the dark underbelly of Mumbai's crime world. Each episode unveils a new mystery while building an overarching narrative of corruption and justice.",
  isPremium: true,
  totalSeasons: 2,
  episodes: [
    {
      id: 1,
      season: 1,
      episode: 1,
      title: "The Beginning",
      duration: "45 min",
      description: "A mysterious murder in South Mumbai sets the stage for a complex investigation.",
      videoUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
      thumbnail: "/placeholder.svg?height=200&width=300&text=Episode+1",
      releaseDate: "2024-01-01",
    },
    {
      id: 2,
      season: 1,
      episode: 2,
      title: "The Investigation",
      duration: "42 min",
      description: "Detective Sharma digs deeper into the case, uncovering unexpected connections.",
      videoUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4",
      thumbnail: "/placeholder.svg?height=200&width=300&text=Episode+2",
      releaseDate: "2024-01-08",
    },
    {
      id: 3,
      season: 1,
      episode: 3,
      title: "Hidden Secrets",
      duration: "48 min",
      description: "The investigation takes a dark turn as family secrets come to light.",
      videoUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
      thumbnail: "/placeholder.svg?height=200&width=300&text=Episode+3",
      releaseDate: "2024-01-15",
    },
    {
      id: 4,
      season: 2,
      episode: 1,
      title: "New Beginnings",
      duration: "50 min",
      description: "Season 2 opens with a new case that connects to the previous season's events.",
      videoUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4",
      thumbnail: "/placeholder.svg?height=200&width=300&text=S2E1",
      releaseDate: "2024-06-01",
    },
  ],
}

export default function SeriesDetail() {
  const [selectedEpisode, setSelectedEpisode] = useState<any>(null)
  const [selectedSeason, setSelectedSeason] = useState(1)
  const [user, setUser] = useState<any>(() => {
    if (typeof window !== "undefined") {
      const userData = localStorage.getItem("user")
      return userData ? JSON.parse(userData) : null
    }
    return null
  })

  const seasons = [...new Set(seriesData.episodes.map((ep) => ep.season))]

  const handleWatchEpisode = (episode: any) => {
    if (!user) {
      alert("Please login to watch episodes")
      return
    }
    setSelectedEpisode(episode)
  }

  const handleDownloadEpisode = (episode: any) => {
    if (!user) {
      alert("Please login to download episodes")
      return
    }

    // Add to downloads
    const downloads = JSON.parse(localStorage.getItem("downloads") || "[]")
    downloads.push({
      id: `${seriesData.id}-${episode.id}`,
      title: `${seriesData.title} - S${episode.season}E${episode.episode}`,
      downloadDate: new Date().toISOString(),
      size: "800 MB",
      status: "completed",
      type: "episode",
    })
    localStorage.setItem("downloads", JSON.stringify(downloads))
    alert(`Downloaded: ${episode.title}`)
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="relative">
        <div className="absolute top-4 left-4 z-10">
          <Link href="/">
            <Button variant="ghost" size="icon" className="bg-black/50 hover:bg-black/70">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
        </div>

        <div className="absolute top-4 right-4 z-10 flex gap-2">
          <Button variant="ghost" size="icon" className="bg-black/50 hover:bg-black/70">
            <Share className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="bg-black/50 hover:bg-black/70">
            <Heart className="h-5 w-5" />
          </Button>
        </div>

        <div className="relative h-64 overflow-hidden">
          <img
            src={seriesData.backdrop || "/placeholder.svg"}
            alt={seriesData.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent" />
        </div>
      </header>

      {/* Series Info */}
      <main className="container mx-auto px-4 -mt-20 relative z-10">
        <div className="flex gap-4 mb-6">
          <img
            src={seriesData.image || "/placeholder.svg"}
            alt={seriesData.title}
            className="w-32 h-48 object-cover rounded-lg shadow-lg"
          />
          <div className="flex-1 pt-16">
            <h1 className="text-2xl font-bold mb-2">{seriesData.title}</h1>
            <div className="flex items-center gap-2 mb-3">
              <div className="flex items-center gap-1 bg-yellow-600 px-2 py-1 rounded">
                <Star className="h-4 w-4 fill-current" />
                <span className="text-sm font-medium">{seriesData.rating}</span>
              </div>
              <span className="text-gray-400">{seriesData.year}</span>
              <span className="text-gray-400">•</span>
              <span className="text-gray-400">{seriesData.totalSeasons} Seasons</span>
            </div>
            <div className="flex flex-wrap gap-2 mb-4">
              {seriesData.genre.map((g) => (
                <Badge key={g} variant="secondary" className="bg-gray-700">
                  {g}
                </Badge>
              ))}
              {seriesData.isPremium && <Badge className="bg-yellow-600 text-black">Premium</Badge>}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 mb-6">
          <Button
            onClick={() => handleWatchEpisode(seriesData.episodes[0])}
            className="flex-1 bg-red-600 hover:bg-red-700"
          >
            <Play className="h-5 w-5 mr-2" />
            Watch Now
          </Button>
          <Button variant="outline" className="border-gray-600 bg-transparent">
            <Plus className="h-5 w-5 mr-2" />
            Watchlist
          </Button>
        </div>

        {/* Description */}
        <section className="mb-8">
          <h2 className="text-lg font-semibold mb-3">Synopsis</h2>
          <p className="text-gray-300 leading-relaxed">{seriesData.description}</p>
        </section>

        {/* Cast & Crew */}
        <section className="mb-8">
          <h2 className="text-lg font-semibold mb-3">Cast & Crew</h2>
          <div className="space-y-2">
            <div>
              <span className="text-gray-400">Director: </span>
              <span>{seriesData.director}</span>
            </div>
            <div>
              <span className="text-gray-400">Cast: </span>
              <span>{seriesData.cast.join(", ")}</span>
            </div>
          </div>
        </section>

        {/* Episodes Section */}
        <section className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Episodes</h2>

          <Tabs value={selectedSeason.toString()} onValueChange={(value) => setSelectedSeason(Number(value))}>
            <TabsList className="grid grid-cols-2 w-full max-w-md mb-6">
              {seasons.map((season) => (
                <TabsTrigger key={season} value={season.toString()}>
                  Season {season}
                </TabsTrigger>
              ))}
            </TabsList>

            {seasons.map((season) => (
              <TabsContent key={season} value={season.toString()}>
                <div className="space-y-4">
                  {seriesData.episodes
                    .filter((ep) => ep.season === season)
                    .map((episode) => (
                      <Card key={episode.id} className="bg-gray-800 border-gray-700 overflow-hidden">
                        <div className="flex">
                          <div className="relative w-48 h-28">
                            <img
                              src={episode.thumbnail || "/placeholder.svg"}
                              alt={episode.title}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                              <Button
                                size="sm"
                                onClick={() => handleWatchEpisode(episode)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                <Play className="h-4 w-4" />
                              </Button>
                            </div>
                            <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-xs">
                              {episode.duration}
                            </div>
                          </div>
                          <CardContent className="flex-1 p-4">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <h3 className="font-semibold text-lg mb-1">
                                  {episode.episode}. {episode.title}
                                </h3>
                                <p className="text-sm text-gray-400 mb-2">
                                  Released: {new Date(episode.releaseDate).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                            <p className="text-sm text-gray-300 mb-3 line-clamp-2">{episode.description}</p>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => handleWatchEpisode(episode)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                <Play className="h-4 w-4 mr-1" />
                                Watch
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDownloadEpisode(episode)}
                                className="border-gray-600 bg-transparent"
                              >
                                <Download className="h-4 w-4 mr-1" />
                                Download
                              </Button>
                            </div>
                          </CardContent>
                        </div>
                      </Card>
                    ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </section>
      </main>

      {/* Video Player Modal */}
      {selectedEpisode && (
        <VideoPlayer
          movie={{
            ...selectedEpisode,
            title: `${seriesData.title} - S${selectedEpisode.season}E${selectedEpisode.episode}: ${selectedEpisode.title}`,
          }}
          user={user}
          onClose={() => setSelectedEpisode(null)}
        />
      )}
    </div>
  )
}
