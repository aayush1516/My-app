"use client"

import { useState } from "react"
import { User, Crown, Download, Settings, LogOut, Edit } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import Link from "next/link"

export default function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false)
  const [userInfo, setUserInfo] = useState({
    name: "John Doe",
    email: "john@example.com",
    phone: "+91 9876543210",
    plan: "Premium Yearly",
    joinDate: "January 2024",
  })

  const downloadedMovies = [
    { id: 1, title: "Action Hero", size: "1.2 GB", downloadDate: "2024-01-15" },
    { id: 2, title: "Romantic Drama", size: "950 MB", downloadDate: "2024-01-10" },
    { id: 3, title: "Comedy Special", size: "800 MB", downloadDate: "2024-01-05" },
  ]

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="border-b border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <h1 className="text-2xl font-bold text-red-500">StreamMax</h1>
            </Link>
            <Link href="/">
              <Button variant="ghost">← Back to Home</Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Profile Info */}
          <div className="lg:col-span-1">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="text-center">
                <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-r from-red-600 to-pink-600 rounded-full flex items-center justify-center">
                  <User className="h-12 w-12 text-white" />
                </div>
                <CardTitle className="flex items-center justify-center gap-2">
                  {userInfo.name}
                  <Badge className="bg-yellow-600 text-black">
                    <Crown className="h-3 w-3 mr-1" />
                    No Ads
                  </Badge>
                </CardTitle>
                <p className="text-gray-400">{userInfo.email}</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <Badge variant="outline" className="border-green-500 text-green-500">
                    {userInfo.plan}
                  </Badge>
                  <p className="text-sm text-gray-400 mt-2">Member since {userInfo.joinDate}</p>
                </div>

                <div className="space-y-2">
                  <Button onClick={() => setIsEditing(!isEditing)} variant="outline" className="w-full border-gray-600">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Profile
                  </Button>
                  <Button variant="outline" className="w-full border-gray-600 bg-transparent">
                    <Settings className="h-4 w-4 mr-2" />
                    Settings
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full border-red-600 text-red-500 hover:bg-red-600 hover:text-white bg-transparent"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Edit Profile Form */}
            {isEditing && (
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle>Edit Profile</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="Full Name"
                      value={userInfo.name}
                      onChange={(e) => setUserInfo({ ...userInfo, name: e.target.value })}
                      className="bg-gray-700 border-gray-600"
                    />
                    <Input
                      placeholder="Email"
                      value={userInfo.email}
                      onChange={(e) => setUserInfo({ ...userInfo, email: e.target.value })}
                      className="bg-gray-700 border-gray-600"
                    />
                  </div>
                  <Input
                    placeholder="Phone Number"
                    value={userInfo.phone}
                    onChange={(e) => setUserInfo({ ...userInfo, phone: e.target.value })}
                    className="bg-gray-700 border-gray-600"
                  />
                  <div className="flex gap-2">
                    <Button className="bg-red-600 hover:bg-red-700">Save Changes</Button>
                    <Button variant="outline" onClick={() => setIsEditing(false)}>
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Subscription Status */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Subscription Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-600/20 to-blue-600/20 rounded-lg border border-green-500/30">
                  <div>
                    <h3 className="font-semibold text-green-400">Premium Yearly Plan</h3>
                    <p className="text-sm text-gray-400">Valid until: December 31, 2024</p>
                    <p className="text-sm text-gray-400">Auto-renewal: Enabled</p>
                  </div>
                  <Badge className="bg-green-600 text-white">Active</Badge>
                </div>
                <div className="mt-4 flex gap-2">
                  <Link href="/plans">
                    <Button variant="outline" className="border-gray-600 bg-transparent">
                      Upgrade Plan
                    </Button>
                  </Link>
                  <Button variant="outline" className="border-gray-600 bg-transparent">
                    Manage Subscription
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Downloaded Movies */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="h-5 w-5" />
                  Downloaded Movies
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {downloadedMovies.map((movie) => (
                    <div key={movie.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                      <div>
                        <h4 className="font-medium">{movie.title}</h4>
                        <p className="text-sm text-gray-400">
                          {movie.size} • Downloaded on {movie.downloadDate}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="border-gray-600 bg-transparent">
                          Watch
                        </Button>
                        <Button size="sm" variant="outline" className="border-red-600 text-red-500 bg-transparent">
                          Delete
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                {downloadedMovies.length === 0 && (
                  <p className="text-center text-gray-400 py-8">No downloaded movies yet</p>
                )}
              </CardContent>
            </Card>

            {/* Account Settings */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div>
                    <h4 className="font-medium">Change Password</h4>
                    <p className="text-sm text-gray-400">Update your account password</p>
                  </div>
                  <Button size="sm" variant="outline" className="border-gray-600 bg-transparent">
                    Change
                  </Button>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div>
                    <h4 className="font-medium">Email Notifications</h4>
                    <p className="text-sm text-gray-400">Manage your email preferences</p>
                  </div>
                  <Button size="sm" variant="outline" className="border-gray-600 bg-transparent">
                    Manage
                  </Button>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div>
                    <h4 className="font-medium">Privacy Settings</h4>
                    <p className="text-sm text-gray-400">Control your privacy preferences</p>
                  </div>
                  <Button size="sm" variant="outline" className="border-gray-600 bg-transparent">
                    Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
