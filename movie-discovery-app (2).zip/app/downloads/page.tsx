"use client"

import { useState, useEffect } from "react"
import { Download, Play, Trash2, Folder, HardDrive } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"

export default function DownloadsPage() {
  const [downloads, setDownloads] = useState<any[]>([])
  const [storageUsed, setStorageUsed] = useState(0)
  const [totalStorage] = useState(32) // 32GB total storage

  useEffect(() => {
    // Load downloads from localStorage
    const savedDownloads = JSON.parse(localStorage.getItem("downloads") || "[]")
    setDownloads(savedDownloads)

    // Calculate storage used
    const used = savedDownloads.reduce((total: number, item: any) => {
      return total + Number.parseFloat(item.size.replace(" GB", "").replace(" MB", "")) / 1000
    }, 0)
    setStorageUsed(used)
  }, [])

  const deleteDownload = (id: number) => {
    const updatedDownloads = downloads.filter((download) => download.id !== id)
    setDownloads(updatedDownloads)
    localStorage.setItem("downloads", JSON.stringify(updatedDownloads))

    // Recalculate storage
    const used = updatedDownloads.reduce((total: number, item: any) => {
      return total + Number.parseFloat(item.size.replace(" GB", "").replace(" MB", "")) / 1000
    }, 0)
    setStorageUsed(used)
  }

  const storagePercentage = (storageUsed / totalStorage) * 100

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="border-b border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <h1 className="text-2xl font-bold text-red-500">StreamMax</h1>
            </Link>
            <Link href="/">
              <Button variant="ghost">← Back to Home</Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Storage Info */}
        <Card className="bg-gray-800 border-gray-700 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <HardDrive className="h-5 w-5" />
              Storage Usage
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span>Used: {storageUsed.toFixed(1)} GB</span>
                <span>Available: {(totalStorage - storageUsed).toFixed(1)} GB</span>
              </div>
              <Progress value={storagePercentage} className="w-full" />
              <p className="text-sm text-gray-400">
                {storagePercentage.toFixed(1)}% of {totalStorage} GB used
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Downloads Section */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Download className="h-6 w-6" />
            My Downloads ({downloads.length})
          </h2>
          <Button variant="outline" className="border-gray-600 bg-transparent">
            <Folder className="h-4 w-4 mr-2" />
            Manage Storage
          </Button>
        </div>

        {downloads.length === 0 ? (
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="text-center py-12">
              <Download className="h-16 w-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Downloads Yet</h3>
              <p className="text-gray-400 mb-6">
                Start downloading your favorite movies and series for offline viewing
              </p>
              <Link href="/">
                <Button className="bg-red-600 hover:bg-red-700">Browse Content</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {downloads.map((download) => (
              <Card key={download.id} className="bg-gray-800 border-gray-700">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <img
                        src="/placeholder.svg?height=80&width=60&text=Movie"
                        alt={download.title}
                        className="w-15 h-20 object-cover rounded"
                      />
                      <div>
                        <h3 className="font-semibold text-lg">{download.title}</h3>
                        <div className="flex items-center gap-4 text-sm text-gray-400 mt-1">
                          <span>{download.size}</span>
                          <span>•</span>
                          <span>Downloaded: {new Date(download.downloadDate).toLocaleDateString()}</span>
                        </div>
                        <Badge variant={download.status === "completed" ? "default" : "secondary"} className="mt-2">
                          {download.status === "completed" ? "✓ Complete" : "⏳ Downloading"}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Button className="bg-red-600 hover:bg-red-700" disabled={download.status !== "completed"}>
                        <Play className="h-4 w-4 mr-2" />
                        Watch
                      </Button>
                      <Button
                        variant="outline"
                        className="border-red-600 text-red-500 hover:bg-red-600 hover:text-white bg-transparent"
                        onClick={() => deleteDownload(download.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {download.status === "downloading" && (
                    <div className="mt-4">
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span>Downloading...</span>
                        <span>45%</span>
                      </div>
                      <Progress value={45} className="w-full" />
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Storage Tips */}
        {downloads.length > 0 && (
          <Card className="bg-gray-800 border-gray-700 mt-8">
            <CardHeader>
              <CardTitle>Storage Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>• Delete watched content to free up space</li>
                <li>• Premium users get priority download speeds</li>
                <li>• Downloads expire after 30 days of inactivity</li>
                <li>• Use Wi-Fi for faster downloads and to save mobile data</li>
              </ul>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
