"use client"

import { useState } from "react"
import { Users, Film, CreditCard, Settings, BarChart3, Plus, Edit, Trash2, Eye, Play } from "lucide-react"
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const dashboardStats = [
  { title: "Total Users", value: "12,543", icon: Users, color: "text-blue-500", change: "+12%" },
  { title: "Premium Users", value: "3,421", icon: CreditCard, color: "text-yellow-500", change: "+8%" },
  { title: "Total Movies", value: "1,234", icon: Film, color: "text-green-500", change: "+15%" },
  { title: "Active Ads", value: "23", icon: BarChart3, color: "text-red-500", change: "+3%" },
]

const recentMovies = [
  { id: 1, title: "Latest Blockbuster", genre: "Action", status: "Active", views: "45.2K", uploadType: "file" },
  { id: 2, title: "Romantic Drama", genre: "Romance", status: "Active", views: "32.1K", uploadType: "link" },
  { id: 3, title: "Comedy Special", genre: "Comedy", status: "Pending", views: "18.5K", uploadType: "file" },
]

const users = [
  { id: 1, name: "John Doe", email: "john@example.com", plan: "Premium", status: "Active", joinDate: "2024-01-15" },
  { id: 2, name: "Jane Smith", email: "jane@example.com", plan: "Free", status: "Active", joinDate: "2024-01-10" },
  {
    id: 3,
    name: "Mike Johnson",
    email: "mike@example.com",
    plan: "Premium",
    status: "Blocked",
    joinDate: "2024-01-05",
  },
]

const revenueData = [
  { month: "Jan", revenue: 125000, users: 450 },
  { month: "Feb", revenue: 178000, users: 620 },
  { month: "Mar", revenue: 195000, users: 750 },
  { month: "Apr", revenue: 210000, users: 890 },
  { month: "May", revenue: 245000, users: 1050 },
  { month: "Jun", revenue: 267000, users: 1200 },
]

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [showAddMovie, setShowAddMovie] = useState(false)
  const [uploadType, setUploadType] = useState("file")
  const [movieForm, setMovieForm] = useState({
    title: "",
    genre: "",
    year: "",
    duration: "",
    rating: "",
    description: "",
    isPremium: false,
    videoFile: null,
    externalLink: "",
    poster: null,
  })
  // Add new state variables after existing useState declarations
  const [showRoleModal, setShowRoleModal] = useState(false)
  const [showBulkModal, setShowBulkModal] = useState(false)
  const [showEmailModal, setShowEmailModal] = useState(false)
  const [selectedMovies, setSelectedMovies] = useState<number[]>([])
  const [bulkAction, setBulkAction] = useState("")

  // Add analytics data before the render functions

  // Add these new render functions before the existing render functions
  const renderAdvancedAnalytics = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Advanced Analytics</h2>

      {/* Revenue & User Growth Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Revenue Growth</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip
                  contentStyle={{ backgroundColor: "#374151", border: "none", borderRadius: "8px" }}
                  labelStyle={{ color: "#F9FAFB" }}
                />
                <Line type="monotone" dataKey="revenue" stroke="#EF4444" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>User Growth</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip
                  contentStyle={{ backgroundColor: "#374151", border: "none", borderRadius: "8px" }}
                  labelStyle={{ color: "#F9FAFB" }}
                />
                <Bar dataKey="users" fill="#EF4444" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  const renderRoleManagement = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Role Management</h2>
        <Button onClick={() => setShowRoleModal(true)} className="bg-red-600 hover:bg-red-700">
          <Plus className="h-4 w-4 mr-2" />
          Add Role
        </Button>
      </div>

      {/* Current Roles */}
      <div className="grid md:grid-cols-3 gap-6">
        {[
          {
            id: 1,
            name: "Super Admin",
            users: 1,
            permissions: [
              "Full Access",
              "User Management",
              "Content Management",
              "Payment Management",
              "System Settings",
            ],
            color: "red",
          },
          {
            id: 2,
            name: "Content Manager",
            users: 3,
            permissions: ["Content Management", "User Viewing", "Analytics Viewing", "Basic Settings"],
            color: "blue",
          },
          {
            id: 3,
            name: "Moderator",
            users: 5,
            permissions: ["Content Viewing", "User Management", "Basic Analytics"],
            color: "green",
          },
        ].map((role) => (
          <Card key={role.id} className={`bg-gray-800 border-gray-700 border-${role.color}-500/50`}>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className={`text-${role.color}-400`}>{role.name}</CardTitle>
                <Badge variant="secondary">{role.users} users</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <h4 className="font-medium mb-2">Permissions:</h4>
                  <div className="space-y-1">
                    {role.permissions.map((permission, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm">
                        <div className={`w-2 h-2 bg-${role.color}-500 rounded-full`}></div>
                        {permission}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="flex gap-2 mt-4">
                  <Button size="sm" variant="outline" className="border-gray-600 bg-transparent">
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  <Button size="sm" variant="outline" className="border-red-600 text-red-500 bg-transparent">
                    <Trash2 className="h-4 w-4 mr-1" />
                    Delete
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Admin Users */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle>Admin Users</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              {
                id: 1,
                name: "Admin User",
                email: "admin@streammax.com",
                role: "Super Admin",
                lastLogin: "2024-01-15 14:30",
                status: "Active",
              },
              {
                id: 2,
                name: "Content Manager",
                email: "content@streammax.com",
                role: "Content Manager",
                lastLogin: "2024-01-15 12:45",
                status: "Active",
              },
              {
                id: 3,
                name: "Moderator 1",
                email: "mod1@streammax.com",
                role: "Moderator",
                lastLogin: "2024-01-14 18:20",
                status: "Inactive",
              },
            ].map((admin) => (
              <div key={admin.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                <div>
                  <h4 className="font-medium">{admin.name}</h4>
                  <p className="text-sm text-gray-400">{admin.email}</p>
                  <p className="text-xs text-gray-500">Last login: {admin.lastLogin}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={admin.role === "Super Admin" ? "default" : "secondary"}>{admin.role}</Badge>
                  <Badge variant={admin.status === "Active" ? "default" : "secondary"}>{admin.status}</Badge>
                  <Select defaultValue={admin.role.toLowerCase().replace(" ", "-")}>
                    <SelectTrigger className="w-40 bg-gray-600 border-gray-500">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="super-admin">Super Admin</SelectItem>
                      <SelectItem value="content-manager">Content Manager</SelectItem>
                      <SelectItem value="moderator">Moderator</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button size="sm" variant="outline" className="border-gray-600 bg-transparent">
                    {admin.status === "Active" ? "Deactivate" : "Activate"}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Role Creation Modal */}
      {showRoleModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <Card className="bg-gray-800 border-gray-700 w-full max-w-md mx-4">
            <CardHeader>
              <CardTitle>Create New Role</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input placeholder="Role Name" className="bg-gray-700 border-gray-600" />
              <div>
                <label className="text-sm font-medium mb-2 block">Permissions</label>
                <div className="space-y-2">
                  {[
                    "User Management",
                    "Content Management",
                    "Payment Management",
                    "Analytics Viewing",
                    "System Settings",
                    "Role Management",
                  ].map((permission) => (
                    <div key={permission} className="flex items-center space-x-2">
                      <Switch />
                      <label className="text-sm">{permission}</label>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex gap-2">
                <Button className="flex-1 bg-red-600 hover:bg-red-700">Create Role</Button>
                <Button
                  variant="outline"
                  onClick={() => setShowRoleModal(false)}
                  className="flex-1 border-gray-600 bg-transparent"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )

  const renderBulkOperations = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Bulk Operations</h2>
        <div className="flex gap-2">
          <Button
            onClick={() => setShowBulkModal(true)}
            disabled={selectedMovies.length === 0}
            className="bg-red-600 hover:bg-red-700 disabled:bg-gray-600"
          >
            Bulk Actions ({selectedMovies.length})
          </Button>
          <Button variant="outline" className="border-gray-600 bg-transparent">
            Import Content
          </Button>
        </div>
      </div>

      {/* Bulk Selection Controls */}
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setSelectedMovies(recentMovies.map((m) => m.id))}
                className="border-gray-600 bg-transparent"
              >
                Select All
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setSelectedMovies([])}
                className="border-gray-600 bg-transparent"
              >
                Deselect All
              </Button>
              <span className="text-sm text-gray-400">
                {selectedMovies.length} of {recentMovies.length} selected
              </span>
            </div>
            <div className="flex gap-2">
              <Select onValueChange={setBulkAction}>
                <SelectTrigger className="w-40 bg-gray-700 border-gray-600">
                  <SelectValue placeholder="Bulk Action" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="delete">Delete Selected</SelectItem>
                  <SelectItem value="activate">Activate All</SelectItem>
                  <SelectItem value="deactivate">Deactivate All</SelectItem>
                  <SelectItem value="premium">Make Premium</SelectItem>
                  <SelectItem value="free">Make Free</SelectItem>
                  <SelectItem value="category">Change Category</SelectItem>
                </SelectContent>
              </Select>
              <Button
                size="sm"
                disabled={!bulkAction || selectedMovies.length === 0}
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600"
              >
                Apply
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Content List with Checkboxes */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle>All Content ({recentMovies.length} items)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentMovies.map((movie) => (
              <div key={movie.id} className="flex items-center gap-4 p-4 bg-gray-700 rounded-lg">
                <input
                  type="checkbox"
                  checked={selectedMovies.includes(movie.id)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedMovies([...selectedMovies, movie.id])
                    } else {
                      setSelectedMovies(selectedMovies.filter((id) => id !== movie.id))
                    }
                  }}
                  className="w-4 h-4 text-red-600 bg-gray-600 border-gray-500 rounded"
                />
                <img
                  src="/placeholder.svg?height=60&width=40&text=Movie"
                  alt={movie.title}
                  className="w-12 h-18 object-cover rounded"
                />
                <div className="flex-1">
                  <h4 className="font-medium">{movie.title}</h4>
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span>{movie.genre}</span>
                    <span>•</span>
                    <span>{movie.views} views</span>
                    <Badge variant="outline" className="text-xs">
                      {movie.uploadType === "file" ? "📁 File" : "🔗 Link"}
                    </Badge>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={movie.status === "Active" ? "default" : "secondary"}>{movie.status}</Badge>
                  <Button size="sm" variant="ghost">
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="ghost">
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Bulk Action Modal */}
      {showBulkModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <Card className="bg-gray-800 border-gray-700 w-full max-w-md mx-4">
            <CardHeader>
              <CardTitle>Confirm Bulk Action</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-300">
                Are you sure you want to apply bulk action to {selectedMovies.length} selected items?
              </p>
              <div className="bg-gray-700 p-3 rounded">
                <p className="text-sm">
                  <span className="font-medium">Action:</span> {bulkAction || "No action selected"}
                </p>
                <p className="text-sm">
                  <span className="font-medium">Items:</span> {selectedMovies.length} selected
                </p>
              </div>
              <div className="flex gap-2">
                <Button className="flex-1 bg-red-600 hover:bg-red-700">Confirm</Button>
                <Button
                  variant="outline"
                  onClick={() => setShowBulkModal(false)}
                  className="flex-1 border-gray-600 bg-transparent"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )

  const renderEmailCampaigns = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Email Campaigns</h2>
        <Button onClick={() => setShowEmailModal(true)} className="bg-red-600 hover:bg-red-700">
          <Plus className="h-4 w-4 mr-2" />
          Create Campaign
        </Button>
      </div>

      {/* Campaign Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        {[
          { label: "Total Campaigns", value: "24", color: "blue" },
          { label: "Active Campaigns", value: "3", color: "green" },
          { label: "Total Subscribers", value: "12,543", color: "purple" },
          { label: "Avg Open Rate", value: "28.5%", color: "yellow" },
        ].map((stat, index) => (
          <Card key={index} className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-white">{stat.value}</p>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Campaigns */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle>Recent Campaigns</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              {
                id: 1,
                name: "New Year Special Offer",
                subject: "🎉 Save 58% on Yearly Premium - Limited Time!",
                recipients: 12543,
                sent: "2024-01-01",
                openRate: "32.4%",
                clickRate: "8.7%",
                status: "Completed",
              },
              {
                id: 2,
                name: "New Movies Alert",
                subject: "🔥 Latest Bollywood Blockbusters Added",
                recipients: 8420,
                sent: "2024-01-10",
                openRate: "28.1%",
                clickRate: "12.3%",
                status: "Completed",
              },
              {
                id: 3,
                name: "Premium Upgrade Reminder",
                subject: "Unlock Premium Features - Start Your Free Trial",
                recipients: 4123,
                sent: "Draft",
                openRate: "-",
                clickRate: "-",
                status: "Draft",
              },
            ].map((campaign) => (
              <div key={campaign.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                <div className="flex-1">
                  <h4 className="font-medium">{campaign.name}</h4>
                  <p className="text-sm text-gray-400 mb-2">{campaign.subject}</p>
                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    <span>
                      Recipients:{" "}
                      {typeof campaign.recipients === "number"
                        ? campaign.recipients.toLocaleString()
                        : campaign.recipients}
                    </span>
                    {campaign.openRate !== "-" && (
                      <>
                        <span>•</span>
                        <span>Open: {campaign.openRate}</span>
                        <span>•</span>
                        <span>Click: {campaign.clickRate}</span>
                      </>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge
                    variant={
                      campaign.status === "Completed"
                        ? "default"
                        : campaign.status === "Draft"
                          ? "secondary"
                          : "secondary"
                    }
                  >
                    {campaign.status}
                  </Badge>
                  <div className="flex gap-1">
                    {campaign.status === "Draft" && (
                      <Button size="sm" variant="outline" className="border-green-600 text-green-400 bg-transparent">
                        Send
                      </Button>
                    )}
                    <Button size="sm" variant="outline" className="border-gray-600 bg-transparent">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" className="border-gray-600 bg-transparent">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Email Templates */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle>Email Templates</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            {[
              { name: "Welcome Email", description: "New user welcome message", usage: "Auto-send", type: "System" },
              {
                name: "Premium Upgrade",
                description: "Promote premium plans",
                usage: "Marketing",
                type: "Promotional",
              },
              {
                name: "New Content Alert",
                description: "Notify about new movies/series",
                usage: "Weekly",
                type: "Content",
              },
              {
                name: "Payment Reminder",
                description: "Subscription renewal reminder",
                usage: "Auto-send",
                type: "System",
              },
              {
                name: "Special Offers",
                description: "Discount and promotional offers",
                usage: "Campaign",
                type: "Promotional",
              },
              {
                name: "Account Security",
                description: "Security alerts and updates",
                usage: "Auto-send",
                type: "System",
              },
            ].map((template, index) => (
              <div key={index} className="p-4 bg-gray-700 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-medium">{template.name}</h4>
                  <Badge variant="outline" className="text-xs">
                    {template.type}
                  </Badge>
                </div>
                <p className="text-sm text-gray-400 mb-3">{template.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">{template.usage}</span>
                  <div className="flex gap-1">
                    <Button size="sm" variant="outline" className="border-gray-600 bg-transparent text-xs px-2 py-1">
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-blue-600 text-blue-400 bg-transparent text-xs px-2 py-1"
                    >
                      Use
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Email Campaign Creation Modal */}
      {showEmailModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <Card className="bg-gray-800 border-gray-700 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <CardTitle>Create Email Campaign</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Campaign Name</label>
                  <Input placeholder="Enter campaign name" className="bg-gray-700 border-gray-600" />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Email Template</label>
                  <Select>
                    <SelectTrigger className="bg-gray-700 border-gray-600">
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="welcome">Welcome Email</SelectItem>
                      <SelectItem value="premium">Premium Upgrade</SelectItem>
                      <SelectItem value="content">New Content Alert</SelectItem>
                      <SelectItem value="offer">Special Offers</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Email Subject</label>
                <Input placeholder="Enter email subject line" className="bg-gray-700 border-gray-600" />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Target Audience</label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      defaultChecked
                      className="w-4 h-4 text-red-600 bg-gray-600 border-gray-500 rounded"
                    />
                    <label className="text-sm">All Users (12,543)</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" className="w-4 h-4 text-red-600 bg-gray-600 border-gray-500 rounded" />
                    <label className="text-sm">Free Users Only (8,122)</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" className="w-4 h-4 text-red-600 bg-gray-600 border-gray-500 rounded" />
                    <label className="text-sm">Premium Users Only (4,421)</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" className="w-4 h-4 text-red-600 bg-gray-600 border-gray-500 rounded" />
                    <label className="text-sm">Inactive Users (Last 30 days)</label>
                  </div>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Email Content</label>
                <Textarea
                  placeholder="Write your email content here..."
                  className="bg-gray-700 border-gray-600 h-32"
                  defaultValue="Hi {name},\n\nWe have exciting news for you! \n\n[Your content here]\n\nBest regards,\nStreamMax Team"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Schedule</label>
                <Select>
                  <SelectTrigger className="bg-gray-700 border-gray-600">
                    <SelectValue placeholder="Send immediately" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="now">Send Now</SelectItem>
                    <SelectItem value="schedule">Schedule for Later</SelectItem>
                    <SelectItem value="draft">Save as Draft</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Priority</label>
                <Select>
                  <SelectTrigger className="bg-gray-700 border-gray-600">
                    <SelectValue placeholder="Normal" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2">
                <Button className="flex-1 bg-red-600 hover:bg-red-700">Send Campaign</Button>
                <Button variant="outline" className="flex-1 border-gray-600 bg-transparent">
                  Save Draft
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )

  // Update the navigation array to include new tabs
  const navigation = [
    { id: "dashboard", label: "Dashboard", icon: BarChart3 },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
    { id: "movies", label: "Movies & Series", icon: Film },
    { id: "bulk", label: "Bulk Operations", icon: Film },
    { id: "users", label: "Users", icon: Users },
    { id: "roles", label: "Role Management", icon: Users },
    { id: "campaigns", label: "Email Campaigns", icon: Users },
    { id: "ads", label: "Ads Management", icon: Play },
    { id: "payments", label: "Payments", icon: CreditCard },
    { id: "settings", label: "Settings", icon: Settings },
    { id: "plans", label: "Plan Management", icon: CreditCard },
  ]

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="border-b border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-red-500">StreamMax Admin</h1>
            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm">
                View Site
              </Button>
              <Button variant="outline" size="sm">
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-7 w-full max-w-4xl">
            {navigation.map((item) => (
              <TabsTrigger key={item.id} value={item.id} className="flex items-center gap-2">
                <item.icon className="h-4 w-4" />
                <span className="hidden sm:inline">{item.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {dashboardStats.map((stat) => (
                <Card key={stat.title} className="bg-gray-800 border-gray-700">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                    <stat.icon className={`h-4 w-4 ${stat.color}`} />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stat.value}</div>
                    <p className="text-xs text-muted-foreground">
                      <span className="text-green-500">{stat.change}</span> from last month
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Recent Activity */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Recent Movies</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentMovies.map((movie) => (
                    <div key={movie.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                      <div>
                        <h4 className="font-medium">{movie.title}</h4>
                        <p className="text-sm text-gray-400">
                          {movie.genre} • {movie.views} views
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={movie.status === "Active" ? "default" : "secondary"}>{movie.status}</Badge>
                        <Button size="sm" variant="ghost">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            {renderAdvancedAnalytics()}
          </TabsContent>

          {/* Movies Tab */}
          <TabsContent value="movies" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Content Management</h2>
              <Button onClick={() => setShowAddMovie(true)} className="bg-red-600 hover:bg-red-700">
                <Plus className="h-4 w-4 mr-2" />
                Add Movie
              </Button>
            </div>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>All Movies & Series</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentMovies.map((movie) => (
                    <div key={movie.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                      <div className="flex items-center gap-4">
                        <img
                          src="/placeholder.svg?height=60&width=40&text=Movie"
                          alt={movie.title}
                          className="w-12 h-18 object-cover rounded"
                        />
                        <div>
                          <h4 className="font-medium">{movie.title}</h4>
                          <p className="text-sm text-gray-400">
                            {movie.genre} • {movie.views} views
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={movie.status === "Active" ? "default" : "secondary"}>{movie.status}</Badge>
                        <Button size="sm" variant="ghost">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="ghost">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="ghost">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Add Movie Modal */}
            {showAddMovie && (
              <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
                <Card className="bg-gray-800 border-gray-700 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
                  <CardHeader>
                    <CardTitle>Add New Movie/Series</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        placeholder="Title"
                        value={movieForm.title}
                        onChange={(e) => setMovieForm({ ...movieForm, title: e.target.value })}
                        className="bg-gray-700 border-gray-600"
                      />
                      <Select
                        value={movieForm.genre}
                        onValueChange={(value) => setMovieForm({ ...movieForm, genre: value })}
                      >
                        <SelectTrigger className="bg-gray-700 border-gray-600">
                          <SelectValue placeholder="Genre" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="action">Action</SelectItem>
                          <SelectItem value="drama">Drama</SelectItem>
                          <SelectItem value="comedy">Comedy</SelectItem>
                          <SelectItem value="thriller">Thriller</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <Input
                        placeholder="Year"
                        value={movieForm.year}
                        onChange={(e) => setMovieForm({ ...movieForm, year: e.target.value })}
                        className="bg-gray-700 border-gray-600"
                      />
                      <Input
                        placeholder="Duration"
                        value={movieForm.duration}
                        onChange={(e) => setMovieForm({ ...movieForm, duration: e.target.value })}
                        className="bg-gray-700 border-gray-600"
                      />
                      <Input
                        placeholder="Rating"
                        value={movieForm.rating}
                        onChange={(e) => setMovieForm({ ...movieForm, rating: e.target.value })}
                        className="bg-gray-700 border-gray-600"
                      />
                    </div>

                    <Textarea
                      placeholder="Description"
                      value={movieForm.description}
                      onChange={(e) => setMovieForm({ ...movieForm, description: e.target.value })}
                      className="bg-gray-700 border-gray-600"
                    />

                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={movieForm.isPremium}
                        onCheckedChange={(checked) => setMovieForm({ ...movieForm, isPremium: checked })}
                      />
                      <label>Premium Content</label>
                    </div>

                    <div className="space-y-4">
                      <div className="flex gap-4">
                        <Button
                          variant={uploadType === "file" ? "default" : "outline"}
                          onClick={() => setUploadType("file")}
                        >
                          Upload File
                        </Button>
                        <Button
                          variant={uploadType === "link" ? "default" : "outline"}
                          onClick={() => setUploadType("link")}
                        >
                          External Link
                        </Button>
                      </div>

                      {uploadType === "file" ? (
                        <Input type="file" accept="video/*" className="bg-gray-700 border-gray-600" />
                      ) : (
                        <Input
                          placeholder="Video URL"
                          value={movieForm.externalLink}
                          onChange={(e) => setMovieForm({ ...movieForm, externalLink: e.target.value })}
                          className="bg-gray-700 border-gray-600"
                        />
                      )}
                    </div>

                    <div className="flex gap-2">
                      <Button className="flex-1 bg-red-600 hover:bg-red-700">Add Movie</Button>
                      <Button
                        variant="outline"
                        onClick={() => setShowAddMovie(false)}
                        className="flex-1 border-gray-600 bg-transparent"
                      >
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">User Management</h2>
              <Button className="bg-red-600 hover:bg-red-700">
                <Plus className="h-4 w-4 mr-2" />
                Add User
              </Button>
            </div>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>All Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {users.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                      <div>
                        <h4 className="font-medium">{user.name}</h4>
                        <p className="text-sm text-gray-400">{user.email}</p>
                        <p className="text-xs text-gray-500">Joined: {user.joinDate}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={user.plan === "Premium" ? "default" : "secondary"}>{user.plan}</Badge>
                        <Badge variant={user.status === "Active" ? "default" : "destructive"}>{user.status}</Badge>
                        <Button size="sm" variant="outline" className="border-gray-600 bg-transparent">
                          Edit
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other tabs would go here */}
          <TabsContent value="ads">
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold mb-2">Ads Management</h3>
              <p className="text-gray-400">Configure and manage advertisement settings</p>
            </div>
          </TabsContent>

          <TabsContent value="payments">
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold mb-2">Payment Management</h3>
              <p className="text-gray-400">View transactions and manage payments</p>
            </div>
          </TabsContent>

          <TabsContent value="settings">
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold mb-2">System Settings</h3>
              <p className="text-gray-400">Configure platform settings and preferences</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
