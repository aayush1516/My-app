"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Play, Download, Heart, Share2, Star, Clock, Calendar, ArrowLeft, Plus } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { VideoPlayer } from "@/components/video-player"
import { RatingReview } from "@/components/social/rating-review"
import { AdBanner } from "@/components/ads/ad-banner"
import { InterstitialAd } from "@/components/ads/interstitial-ad"

// Mock movie data
const movieData = {
  1: {
    id: 1,
    title: "Guardians of the Galaxy Vol. 3",
    genre: "Action, Adventure, Comedy",
    rating: 8.2,
    year: 2023,
    duration: "150 min",
    poster: "/guardians-galaxy-poster.png",
    backdrop: "/guardians-galaxy-vol-3-backdrop.png",
    description:
      "Still reeling from the loss of Gamora, Peter Quill rallies his team to defend the universe and one of their own - a mission that, if not completed successfully, could quite possibly lead to the end of the Guardians as we know them.",
    director: "James Gunn",
    cast: ["Chris Pratt", "Zoe Saldana", "Dave Bautista", "Karen Gillan", "Pom Klementieff"],
    languages: ["English", "Hindi", "Tamil", "Telugu"],
    quality: ["4K", "HD", "SD"],
    videoUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
    trailer: "https://sample-videos.com/zip/10/mp4/SampleVideo_640x360_1mb.mp4",
    reviews: [
      {
        id: 1,
        user: "John Doe",
        rating: 5,
        comment: "Amazing movie! Great conclusion to the trilogy.",
        date: "2023-05-15",
      },
      {
        id: 2,
        user: "Jane Smith",
        rating: 4,
        comment: "Emotional and action-packed. Loved it!",
        date: "2023-05-14",
      },
    ],
  },
}

const relatedMovies = [
  {
    id: 2,
    title: "Spider-Man: Across the Spider-Verse",
    poster: "/spider-verse-poster.png",
    rating: 8.7,
  },
  {
    id: 3,
    title: "John Wick: Chapter 4",
    poster: "/john-wick-chapter-4-inspired-poster.png",
    rating: 7.8,
  },
  {
    id: 4,
    title: "Fast X",
    poster: "/fast-x-movie-poster.png",
    rating: 5.8,
  },
]

export default function MoviePage({ params }: { params: { id: string } }) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [showTrailer, setShowTrailer] = useState(false)
  const [isLiked, setIsLiked] = useState(false)
  const [isInWatchlist, setIsInWatchlist] = useState(false)
  const [showInterstitial, setShowInterstitial] = useState(false)

  const movieId = Number.parseInt(params.id)
  const movie = movieData[movieId as keyof typeof movieData]

  useEffect(() => {
    // Show interstitial ad after 30 seconds
    const timer = setTimeout(() => {
      setShowInterstitial(true)
    }, 30000)

    return () => clearTimeout(timer)
  }, [])

  if (!movie) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Movie Not Found</h1>
          <Link href="/">
            <Button>Go Back Home</Button>
          </Link>
        </div>
      </div>
    )
  }

  const handlePlayMovie = () => {
    setIsPlaying(true)
    setShowTrailer(false)
  }

  const handlePlayTrailer = () => {
    setShowTrailer(true)
    setIsPlaying(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <Link href="/" className="text-2xl font-bold text-primary">
              StreamMax
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsLiked(!isLiked)}
              className={isLiked ? "text-red-500" : ""}
            >
              <Heart className={`h-5 w-5 ${isLiked ? "fill-current" : ""}`} />
            </Button>
            <Button variant="ghost" size="icon">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </nav>

      {/* Video Player Section */}
      {(isPlaying || showTrailer) && (
        <div className="fixed inset-0 z-40 bg-black">
          <VideoPlayer
            src={showTrailer ? movie.trailer : movie.videoUrl}
            poster={movie.backdrop}
            title={movie.title}
            onClose={() => {
              setIsPlaying(false)
              setShowTrailer(false)
            }}
          />
        </div>
      )}

      {/* Main Content */}
      <main className="pt-16">
        {/* Hero Section */}
        <section className="relative h-[70vh] overflow-hidden">
          <div className="absolute inset-0">
            <Image
              src={movie.backdrop || "/placeholder.svg"}
              alt={movie.title}
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
          </div>

          <div className="relative container mx-auto px-4 h-full flex items-center">
            <div className="max-w-2xl text-white">
              <h1 className="text-4xl md:text-6xl font-bold mb-4">{movie.title}</h1>
              <div className="flex items-center space-x-4 mb-4 text-sm">
                <div className="flex items-center space-x-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span>{movie.rating}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar className="h-4 w-4" />
                  <span>{movie.year}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="h-4 w-4" />
                  <span>{movie.duration}</span>
                </div>
                <Badge variant="outline">{movie.genre.split(",")[0]}</Badge>
              </div>
              <p className="text-lg mb-6 text-gray-300 leading-relaxed">{movie.description}</p>
              <div className="flex items-center space-x-4 flex-wrap gap-2">
                <Button size="lg" onClick={handlePlayMovie} className="bg-primary hover:bg-primary/90">
                  <Play className="h-5 w-5 mr-2" />
                  Watch Now
                </Button>
                <Button variant="outline" size="lg" onClick={handlePlayTrailer}>
                  <Play className="h-5 w-5 mr-2" />
                  Trailer
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => setIsInWatchlist(!isInWatchlist)}
                  className={isInWatchlist ? "bg-primary/20" : ""}
                >
                  <Plus className="h-5 w-5 mr-2" />
                  {isInWatchlist ? "In Watchlist" : "Watchlist"}
                </Button>
                <Button variant="outline" size="lg">
                  <Download className="h-5 w-5 mr-2" />
                  Download
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Ad Banner */}
        <AdBanner />

        {/* Movie Details */}
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <Tabs defaultValue="details" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="cast">Cast & Crew</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews</TabsTrigger>
                </TabsList>

                <TabsContent value="details" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold mb-4">Movie Information</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-semibold mb-2">Director</h4>
                          <p className="text-muted-foreground">{movie.director}</p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">Genre</h4>
                          <p className="text-muted-foreground">{movie.genre}</p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">Languages</h4>
                          <div className="flex flex-wrap gap-2">
                            {movie.languages.map((lang) => (
                              <Badge key={lang} variant="secondary">
                                {lang}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">Quality</h4>
                          <div className="flex flex-wrap gap-2">
                            {movie.quality.map((quality) => (
                              <Badge key={quality} variant="outline">
                                {quality}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="mt-6">
                        <h4 className="font-semibold mb-2">Synopsis</h4>
                        <p className="text-muted-foreground leading-relaxed">{movie.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="cast" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold mb-4">Cast</h3>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {movie.cast.map((actor, index) => (
                          <div key={index} className="text-center">
                            <div className="w-20 h-20 bg-muted rounded-full mx-auto mb-2 flex items-center justify-center">
                              <span className="text-2xl font-bold text-muted-foreground">
                                {actor
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </span>
                            </div>
                            <p className="font-medium">{actor}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="reviews" className="mt-6">
                  <RatingReview movieId={movie.id} initialReviews={movie.reviews} averageRating={movie.rating} />
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Movie Poster */}
              <Card>
                <CardContent className="p-0">
                  <div className="relative aspect-[2/3] overflow-hidden rounded-lg">
                    <Image src={movie.poster || "/placeholder.svg"} alt={movie.title} fill className="object-cover" />
                  </div>
                </CardContent>
              </Card>

              {/* Related Movies */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4">Related Movies</h3>
                  <div className="space-y-4">
                    {relatedMovies.map((relatedMovie) => (
                      <Link key={relatedMovie.id} href={`/movie/${relatedMovie.id}`}>
                        <div className="flex items-center space-x-3 p-2 rounded-lg hover:bg-muted transition-colors cursor-pointer">
                          <div className="relative w-16 h-20 overflow-hidden rounded">
                            <Image
                              src={relatedMovie.poster || "/placeholder.svg"}
                              alt={relatedMovie.title}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium line-clamp-2">{relatedMovie.title}</h4>
                            <div className="flex items-center space-x-1 mt-1">
                              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                              <span className="text-sm text-muted-foreground">{relatedMovie.rating}</span>
                            </div>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      {/* Interstitial Ad */}
      {showInterstitial && <InterstitialAd onClose={() => setShowInterstitial(false)} />}
    </div>
  )
}
