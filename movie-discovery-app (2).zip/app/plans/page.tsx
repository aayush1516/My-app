"use client"

import { Check, Crown, Star, CreditCard, Zap, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { useState } from "react"

const plans = [
  {
    id: "monthly",
    name: "Monthly Premium",
    originalPrice: "₹300",
    discountedPrice: "₹153",
    duration: "/month",
    color: "from-blue-600 via-purple-600 to-indigo-600",
    borderColor: "border-blue-500",
    buttonColor: "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700",
    icon: Zap,
    iconColor: "text-blue-400",
    features: [
      "Unlimited Movies & Web Series",
      "No Ads Experience",
      "HD Quality Streaming (1080p)",
      "Direct Download Access",
      "Multiple Device Support (3 devices)",
      "Offline Viewing",
      "24/7 Customer Support",
      "New Releases First",
    ],
    popular: false,
    savings: "₹147",
    dailyCost: "₹5.1",
  },
  {
    id: "yearly",
    name: "Yearly Premium",
    originalPrice: "₹3,600",
    discountedPrice: "₹1,530",
    duration: "/year",
    color: "from-red-600 via-pink-600 to-rose-600",
    borderColor: "border-red-500",
    buttonColor: "bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700",
    icon: Crown,
    iconColor: "text-red-400",
    features: [
      "Everything in Monthly Plan",
      "Save 58% with Annual Billing",
      "Priority Customer Support",
      "Early Access to New Content",
      "4K Ultra HD Streaming",
      "Family Sharing (5 devices)",
      "Exclusive Premium Content",
      "Download for Offline (Unlimited)",
      "Ad-Free Experience Forever",
      "Premium Movie Premieres",
    ],
    popular: true,
    savings: "₹2,070",
    dailyCost: "₹4.2",
  },
]

export default function PlansPage() {
  const [isProcessing, setIsProcessing] = useState(false)

  const handlePurchase = async (planId: string, price: string) => {
    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false)
      showSuccessPopup(planId, price)
    }, 2000)
  }

  const showSuccessPopup = (planId: string, price: string) => {
    const user = JSON.parse(localStorage.getItem("user") || "{}")

    user.plan = "premium"
    user.subscriptionDate = new Date().toISOString()
    user.subscriptionType = planId
    localStorage.setItem("user", JSON.stringify(user))

    alert(`🎉 Welcome to Premium! Your ${planId} plan (${price}) is now active!`)
    window.location.href = "/"
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="border-b border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <h1 className="text-2xl font-bold text-red-500">StreamMax</h1>
            </Link>
            <Link href="/">
              <Button variant="ghost">← Back to Home</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 text-center bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="container mx-auto px-4">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-yellow-600 to-orange-600 px-4 py-2 rounded-full text-sm font-semibold mb-6">
            <Star className="h-4 w-4" />
            Limited Time Offer - Save Up to 58%
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Choose Your{" "}
            <span className="bg-gradient-to-r from-red-500 to-pink-500 bg-clip-text text-transparent">Premium</span>{" "}
            Plan
          </h1>
          <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
            Unlock unlimited entertainment with our premium plans. No ads, HD quality, and exclusive content.
          </p>
          <div className="flex items-center justify-center gap-2 mb-8">
            <Shield className="h-5 w-5 text-green-500" />
            <span className="text-gray-300">Trusted by 10,000+ users • Cancel anytime</span>
          </div>
        </div>
      </section>

      {/* Plans Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {plans.map((plan) => (
              <Card
                key={plan.id}
                className={`relative bg-gray-800 border-2 ${plan.popular ? plan.borderColor : "border-gray-700"} overflow-hidden transform hover:scale-105 transition-all duration-300 ${
                  plan.popular ? "shadow-2xl shadow-red-500/20" : "shadow-lg"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-red-600 to-pink-600 text-white px-6 py-2 text-sm font-bold">
                      🔥 MOST POPULAR
                    </Badge>
                  </div>
                )}

                <CardHeader className="text-center pb-8 pt-8">
                  <div
                    className={`w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-r ${plan.color} flex items-center justify-center shadow-lg`}
                  >
                    <plan.icon className={`h-10 w-10 text-white`} />
                  </div>
                  <CardTitle className="text-2xl font-bold mb-2">{plan.name}</CardTitle>

                  <div className="space-y-2">
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                        {plan.discountedPrice}
                      </span>
                      <span className="text-gray-400 text-lg">{plan.duration}</span>
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-lg text-gray-500 line-through">{plan.originalPrice}</span>
                      <Badge variant="secondary" className="bg-gradient-to-r from-green-600 to-emerald-600 text-white">
                        {plan.id === "yearly" ? "58% OFF" : "49% OFF"}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-400">
                      Only {plan.dailyCost} per day • Save {plan.savings}
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-3">
                        <div
                          className={`w-5 h-5 rounded-full bg-gradient-to-r ${plan.color} flex items-center justify-center flex-shrink-0`}
                        >
                          <Check className="h-3 w-3 text-white" />
                        </div>
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    onClick={() => handlePurchase(plan.id, plan.discountedPrice)}
                    disabled={isProcessing}
                    className={`w-full py-4 text-lg font-semibold ${plan.buttonColor} shadow-lg transform hover:scale-105 transition-all duration-200`}
                  >
                    {isProcessing ? (
                      <div className="flex items-center gap-2">
                        <CreditCard className="h-5 w-5 animate-pulse" />
                        Processing...
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-2">
                        <plan.icon className="h-5 w-5" />
                        Get {plan.name}
                      </div>
                    )}
                  </Button>

                  <p className="text-xs text-gray-500 text-center">
                    🔒 Secure payment • Cancel anytime • No hidden fees
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
