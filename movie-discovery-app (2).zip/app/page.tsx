"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Play, Search, Star, Download, User, Menu, Home, Film, Tv, Bell, Heart, Share2, Plus, Zap } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { AdBanner } from "@/components/ads/ad-banner"
import { NotificationSystem } from "@/components/notifications/notification-system"

// Mock data
const featuredMovies = [
  {
    id: 1,
    title: "Guardians of the Galaxy Vol. 3",
    genre: "Action, Adventure, Comedy",
    rating: 8.2,
    year: 2023,
    duration: "150 min",
    poster: "/guardians-galaxy-poster.png",
    backdrop: "/guardians-galaxy-vol-3-backdrop.png",
    description:
      "Still reeling from the loss of Gamora, Peter Quill rallies his team to defend the universe and one of their own.",
  },
  {
    id: 2,
    title: "Spider-Man: Across the Spider-Verse",
    genre: "Animation, Action, Adventure",
    rating: 8.7,
    year: 2023,
    duration: "140 min",
    poster: "/spider-verse-poster.png",
    backdrop: "/spider-verse-poster.png",
    description: "Miles Morales catapults across the Multiverse, where he encounters a team of Spider-People.",
  },
  {
    id: 3,
    title: "John Wick: Chapter 4",
    genre: "Action, Crime, Thriller",
    rating: 7.8,
    year: 2023,
    duration: "169 min",
    poster: "/john-wick-chapter-4-inspired-poster.png",
    backdrop: "/john-wick-chapter-4-inspired-poster.png",
    description: "John Wick uncovers a path to defeating The High Table.",
  },
]

const trendingMovies = [
  {
    id: 4,
    title: "Oppenheimer",
    genre: "Biography, Drama, History",
    rating: 8.4,
    year: 2023,
    poster: "/images/posters/oppenheimer-poster.png",
  },
  {
    id: 5,
    title: "Barbie",
    genre: "Adventure, Comedy, Fantasy",
    rating: 6.9,
    year: 2023,
    poster: "/barbie-movie-poster.png",
  },
  {
    id: 6,
    title: "Fast X",
    genre: "Action, Adventure, Crime",
    rating: 5.8,
    year: 2023,
    poster: "/fast-x-movie-poster.png",
  },
  {
    id: 7,
    title: "The Flash",
    genre: "Action, Adventure, Fantasy",
    rating: 6.7,
    year: 2023,
    poster: "/generic-superhero-movie-poster.png",
  },
  {
    id: 8,
    title: "Indiana Jones 5",
    genre: "Action, Adventure",
    rating: 6.5,
    year: 2023,
    poster: "/indiana-jones-5-poster.png",
  },
]

const webSeries = [
  {
    id: 101,
    title: "Galactic Protectors",
    genre: "Sci-Fi, Action",
    rating: 8.9,
    year: 2023,
    seasons: 3,
    poster: "/galactic-protectors-poster.png",
  },
  {
    id: 102,
    title: "Thunder God Chronicles",
    genre: "Fantasy, Adventure",
    rating: 8.1,
    year: 2023,
    seasons: 2,
    poster: "/thor-love-thunder-inspired-poster.png",
  },
  {
    id: 103,
    title: "Multiverse Madness",
    genre: "Sci-Fi, Fantasy",
    rating: 7.8,
    year: 2023,
    seasons: 1,
    poster: "/multiverse-madness-poster.png",
  },
]

export default function HomePage() {
  const [currentFeatured, setCurrentFeatured] = useState(0)
  const [searchQuery, setSearchQuery] = useState("")
  const [sidebarOpen, setSidebarOpen] = useState(false)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentFeatured((prev) => (prev + 1) % featuredMovies.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  const currentMovie = featuredMovies[currentFeatured]

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setSidebarOpen(!sidebarOpen)}>
              <Menu className="h-5 w-5" />
            </Button>
            <Link href="/" className="text-2xl font-bold text-primary">
              StreamMax
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-6">
            <Link href="/" className="flex items-center space-x-2 text-primary">
              <Home className="h-4 w-4" />
              <span>Home</span>
            </Link>
            <Link href="/search" className="flex items-center space-x-2 hover:text-primary">
              <Film className="h-4 w-4" />
              <span>Movies</span>
            </Link>
            <Link href="/search" className="flex items-center space-x-2 hover:text-primary">
              <Tv className="h-4 w-4" />
              <span>Series</span>
            </Link>
            <Link href="/downloads" className="flex items-center space-x-2 hover:text-primary">
              <Download className="h-4 w-4" />
              <span>Downloads</span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            <div className="relative hidden sm:block">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search movies, series..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
                onKeyPress={(e) => {
                  if (e.key === "Enter" && searchQuery.trim()) {
                    window.location.href = `/search?q=${encodeURIComponent(searchQuery)}`
                  }
                }}
              />
            </div>
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <Link href="/profile">
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Mobile Sidebar */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="fixed inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <div className="fixed left-0 top-0 h-full w-64 bg-background border-r p-4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold">Menu</h2>
              <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(false)}>
                <Menu className="h-5 w-5" />
              </Button>
            </div>
            <nav className="space-y-4">
              <Link href="/" className="flex items-center space-x-3 p-2 rounded-lg bg-primary/10 text-primary">
                <Home className="h-5 w-5" />
                <span>Home</span>
              </Link>
              <Link href="/search" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-muted">
                <Film className="h-5 w-5" />
                <span>Movies</span>
              </Link>
              <Link href="/search" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-muted">
                <Tv className="h-5 w-5" />
                <span>Series</span>
              </Link>
              <Link href="/downloads" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-muted">
                <Download className="h-5 w-5" />
                <span>Downloads</span>
              </Link>
              <Link href="/profile" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-muted">
                <User className="h-5 w-5" />
                <span>Profile</span>
              </Link>
              <Link href="/plans" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-muted">
                <Zap className="h-5 w-5" />
                <span>Premium Plans</span>
              </Link>
            </nav>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="pt-16">
        {/* Hero Section */}
        <section className="relative h-[70vh] overflow-hidden">
          <div className="absolute inset-0">
            <Image
              src={currentMovie.backdrop || "/placeholder.svg"}
              alt={currentMovie.title}
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
          </div>

          <div className="relative container mx-auto px-4 h-full flex items-center">
            <div className="max-w-2xl text-white">
              <Badge variant="secondary" className="mb-4">
                Featured Movie
              </Badge>
              <h1 className="text-4xl md:text-6xl font-bold mb-4">{currentMovie.title}</h1>
              <div className="flex items-center space-x-4 mb-4 text-sm">
                <div className="flex items-center space-x-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span>{currentMovie.rating}</span>
                </div>
                <span>{currentMovie.year}</span>
                <span>{currentMovie.duration}</span>
                <Badge variant="outline">{currentMovie.genre.split(",")[0]}</Badge>
              </div>
              <p className="text-lg mb-6 text-gray-300 leading-relaxed">{currentMovie.description}</p>
              <div className="flex items-center space-x-4">
                <Link href={`/movie/${currentMovie.id}`}>
                  <Button size="lg" className="bg-primary hover:bg-primary/90">
                    <Play className="h-5 w-5 mr-2" />
                    Watch Now
                  </Button>
                </Link>
                <Button variant="outline" size="lg">
                  <Plus className="h-5 w-5 mr-2" />
                  My List
                </Button>
                <Button variant="ghost" size="lg">
                  <Heart className="h-5 w-5 mr-2" />
                  Like
                </Button>
                <Button variant="ghost" size="lg">
                  <Share2 className="h-5 w-5 mr-2" />
                  Share
                </Button>
              </div>
            </div>
          </div>

          {/* Hero Navigation Dots */}
          <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {featuredMovies.map((_, index) => (
              <button
                key={index}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentFeatured ? "bg-white" : "bg-white/50"
                }`}
                onClick={() => setCurrentFeatured(index)}
              />
            ))}
          </div>
        </section>

        {/* Ad Banner */}
        <AdBanner />

        {/* Content Sections */}
        <div className="container mx-auto px-4 py-8 space-y-12">
          {/* Trending Movies */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Trending Movies</h2>
              <Link href="/search?category=trending">
                <Button variant="outline">View All</Button>
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {trendingMovies.map((movie) => (
                <Link key={movie.id} href={`/movie/${movie.id}`}>
                  <Card className="group cursor-pointer hover:scale-105 transition-transform duration-300">
                    <CardContent className="p-0">
                      <div className="relative aspect-[2/3] overflow-hidden rounded-lg">
                        <Image
                          src={movie.poster || "/placeholder.svg"}
                          alt={movie.title}
                          fill
                          className="object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                        <div className="absolute top-2 right-2">
                          <Badge variant="secondary" className="text-xs">
                            <Star className="h-3 w-3 mr-1 fill-yellow-400 text-yellow-400" />
                            {movie.rating}
                          </Badge>
                        </div>
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <Button size="icon" className="rounded-full">
                            <Play className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>
                      <div className="p-3">
                        <h3 className="font-semibold text-sm mb-1 line-clamp-1">{movie.title}</h3>
                        <p className="text-xs text-muted-foreground line-clamp-1">{movie.genre}</p>
                        <p className="text-xs text-muted-foreground">{movie.year}</p>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </section>

          {/* Web Series */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Popular Web Series</h2>
              <Link href="/search?category=series">
                <Button variant="outline">View All</Button>
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {webSeries.map((series) => (
                <Link key={series.id} href={`/series/${series.id}`}>
                  <Card className="group cursor-pointer hover:scale-105 transition-transform duration-300">
                    <CardContent className="p-0">
                      <div className="relative aspect-[2/3] overflow-hidden rounded-lg">
                        <Image
                          src={series.poster || "/placeholder.svg"}
                          alt={series.title}
                          fill
                          className="object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                        <div className="absolute top-2 right-2">
                          <Badge variant="secondary" className="text-xs">
                            <Star className="h-3 w-3 mr-1 fill-yellow-400 text-yellow-400" />
                            {series.rating}
                          </Badge>
                        </div>
                        <div className="absolute top-2 left-2">
                          <Badge variant="default" className="text-xs">
                            {series.seasons} Season{series.seasons > 1 ? "s" : ""}
                          </Badge>
                        </div>
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <Button size="icon" className="rounded-full">
                            <Play className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>
                      <div className="p-3">
                        <h3 className="font-semibold text-sm mb-1 line-clamp-1">{series.title}</h3>
                        <p className="text-xs text-muted-foreground line-clamp-1">{series.genre}</p>
                        <p className="text-xs text-muted-foreground">{series.year}</p>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </section>

          {/* Categories */}
          <section>
            <h2 className="text-2xl font-bold mb-6">Browse by Category</h2>
            <Tabs defaultValue="action" className="w-full">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="action">Action</TabsTrigger>
                <TabsTrigger value="comedy">Comedy</TabsTrigger>
                <TabsTrigger value="drama">Drama</TabsTrigger>
                <TabsTrigger value="horror">Horror</TabsTrigger>
                <TabsTrigger value="sci-fi">Sci-Fi</TabsTrigger>
              </TabsList>
              <TabsContent value="action" className="mt-6">
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {trendingMovies.slice(0, 6).map((movie) => (
                    <Link key={movie.id} href={`/movie/${movie.id}`}>
                      <Card className="group cursor-pointer hover:scale-105 transition-transform duration-300">
                        <CardContent className="p-0">
                          <div className="relative aspect-[2/3] overflow-hidden rounded-lg">
                            <Image
                              src={movie.poster || "/placeholder.svg"}
                              alt={movie.title}
                              fill
                              className="object-cover"
                            />
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/50">
                              <Button size="icon" className="rounded-full">
                                <Play className="h-5 w-5" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="comedy" className="mt-6">
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {trendingMovies.slice(1, 7).map((movie) => (
                    <Link key={movie.id} href={`/movie/${movie.id}`}>
                      <Card className="group cursor-pointer hover:scale-105 transition-transform duration-300">
                        <CardContent className="p-0">
                          <div className="relative aspect-[2/3] overflow-hidden rounded-lg">
                            <Image
                              src={movie.poster || "/placeholder.svg"}
                              alt={movie.title}
                              fill
                              className="object-cover"
                            />
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/50">
                              <Button size="icon" className="rounded-full">
                                <Play className="h-5 w-5" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="drama" className="mt-6">
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {trendingMovies.slice(2, 8).map((movie) => (
                    <Link key={movie.id} href={`/movie/${movie.id}`}>
                      <Card className="group cursor-pointer hover:scale-105 transition-transform duration-300">
                        <CardContent className="p-0">
                          <div className="relative aspect-[2/3] overflow-hidden rounded-lg">
                            <Image
                              src={movie.poster || "/placeholder.svg"}
                              alt={movie.title}
                              fill
                              className="object-cover"
                            />
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/50">
                              <Button size="icon" className="rounded-full">
                                <Play className="h-5 w-5" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="horror" className="mt-6">
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {trendingMovies.slice(0, 6).map((movie) => (
                    <Link key={movie.id} href={`/movie/${movie.id}`}>
                      <Card className="group cursor-pointer hover:scale-105 transition-transform duration-300">
                        <CardContent className="p-0">
                          <div className="relative aspect-[2/3] overflow-hidden rounded-lg">
                            <Image
                              src={movie.poster || "/placeholder.svg"}
                              alt={movie.title}
                              fill
                              className="object-cover"
                            />
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/50">
                              <Button size="icon" className="rounded-full">
                                <Play className="h-5 w-5" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="sci-fi" className="mt-6">
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {trendingMovies.slice(1, 7).map((movie) => (
                    <Link key={movie.id} href={`/movie/${movie.id}`}>
                      <Card className="group cursor-pointer hover:scale-105 transition-transform duration-300">
                        <CardContent className="p-0">
                          <div className="relative aspect-[2/3] overflow-hidden rounded-lg">
                            <Image
                              src={movie.poster || "/placeholder.svg"}
                              alt={movie.title}
                              fill
                              className="object-cover"
                            />
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/50">
                              <Button size="icon" className="rounded-full">
                                <Play className="h-5 w-5" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </section>

          {/* Premium Plans CTA */}
          <section className="bg-gradient-to-r from-primary/10 to-primary/5 rounded-xl p-8 text-center">
            <h2 className="text-3xl font-bold mb-4">Upgrade to Premium</h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Get unlimited access to all movies and series, download for offline viewing, and enjoy ad-free streaming
              with our premium plans.
            </p>
            <Link href="/plans">
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                <Zap className="h-5 w-5 mr-2" />
                View Plans
              </Button>
            </Link>
          </section>
        </div>
      </main>

      {/* Notification System */}
      <NotificationSystem />
    </div>
  )
}
