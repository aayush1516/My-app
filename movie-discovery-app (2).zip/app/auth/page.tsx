"use client"

import type React from "react"

import { useState } from "react"
import { Eye, EyeOff, Mail, Lock, User, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [showOTP, setShowOTP] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    otp: "",
  })
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      if (isLogin) {
        // Login logic
        const userData = {
          id: 1,
          name: formData.email.split("@")[0],
          email: formData.email,
          plan: "free", // or "premium"
          joinDate: new Date().toISOString(),
        }
        localStorage.setItem("user", JSON.stringify(userData))
        router.push("/")
      } else {
        // Signup logic - show OTP
        if (!showOTP) {
          setShowOTP(true)
          alert("OTP sent to your email!")
        } else {
          // Verify OTP and create account
          const userData = {
            id: Date.now(),
            name: formData.name,
            email: formData.email,
            phone: formData.phone,
            plan: "free",
            joinDate: new Date().toISOString(),
          }
          localStorage.setItem("user", JSON.stringify(userData))
          router.push("/")
        }
      }
      setIsLoading(false)
    }, 2000)
  }

  const handleForgotPassword = () => {
    if (!formData.email) {
      alert("Please enter your email first")
      return
    }
    alert("Password reset link sent to your email!")
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-gray-800 border-gray-700">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-red-500">StreamMax</CardTitle>
          <p className="text-gray-400">
            {isLogin ? "Welcome back!" : showOTP ? "Verify your email" : "Create your account"}
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && !showOTP && (
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Full Name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="pl-10 bg-gray-700 border-gray-600"
                  required
                />
              </div>
            )}

            {!showOTP && (
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="email"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="pl-10 bg-gray-700 border-gray-600"
                  required
                />
              </div>
            )}

            {!isLogin && !showOTP && (
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="tel"
                  placeholder="Phone Number"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="pl-10 bg-gray-700 border-gray-600"
                  required
                />
              </div>
            )}

            {showOTP ? (
              <div className="space-y-4">
                <p className="text-sm text-gray-400 text-center">Enter the 6-digit OTP sent to {formData.email}</p>
                <Input
                  type="text"
                  placeholder="Enter OTP"
                  value={formData.otp}
                  onChange={(e) => setFormData({ ...formData, otp: e.target.value })}
                  className="text-center text-2xl tracking-widest bg-gray-700 border-gray-600"
                  maxLength={6}
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  className="w-full text-red-500"
                  onClick={() => alert("OTP resent!")}
                >
                  Resend OTP
                </Button>
              </div>
            ) : (
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="Password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="pl-10 pr-10 bg-gray-700 border-gray-600"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            )}

            {!isLogin && !showOTP && (
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="password"
                  placeholder="Confirm Password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="pl-10 bg-gray-700 border-gray-600"
                  required
                />
              </div>
            )}

            <Button type="submit" disabled={isLoading} className="w-full bg-red-600 hover:bg-red-700">
              {isLoading ? "Please wait..." : showOTP ? "Verify OTP" : isLogin ? "Login" : "Create Account"}
            </Button>

            {isLogin && !showOTP && (
              <Button type="button" variant="ghost" onClick={handleForgotPassword} className="w-full text-red-500">
                Forgot Password?
              </Button>
            )}
          </form>

          {!showOTP && (
            <div className="mt-6 text-center">
              <p className="text-gray-400">{isLogin ? "Don't have an account?" : "Already have an account?"}</p>
              <Button variant="ghost" onClick={() => setIsLogin(!isLogin)} className="text-red-500 hover:text-red-400">
                {isLogin ? "Sign Up" : "Login"}
              </Button>
            </div>
          )}

          <div className="mt-6 pt-6 border-t border-gray-700">
            <p className="text-xs text-gray-500 text-center">
              By continuing, you agree to our Terms of Service and Privacy Policy
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
