"use client"

import { useState, useEffect } from "react"
import { Search, Filter, Star, Play, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import Link from "next/link"

const allContent = [
  {
    id: 1,
    title: "Bollywood Blockbuster",
    type: "movie",
    rating: 8.5,
    year: 2024,
    genre: "Drama",
    language: "Hindi",
    image: "/placeholder.svg?height=400&width=300&text=Movie+1",
    isPremium: false,
  },
  {
    id: 2,
    title: "Action Hero",
    type: "movie",
    rating: 7.8,
    year: 2024,
    genre: "Action",
    language: "Hindi",
    image: "/placeholder.svg?height=400&width=300&text=Movie+2",
    isPremium: true,
  },
  {
    id: 3,
    title: "Crime Stories",
    type: "series",
    rating: 9.1,
    year: 2024,
    genre: "Crime",
    language: "Hindi",
    episodes: 8,
    image: "/placeholder.svg?height=400&width=300&text=Series+1",
    isPremium: true,
  },
  {
    id: 4,
    title: "Comedy Nights",
    type: "series",
    rating: 8.2,
    year: 2024,
    genre: "Comedy",
    language: "Hindi",
    episodes: 12,
    image: "/placeholder.svg?height=400&width=300&text=Series+2",
    isPremium: false,
  },
  {
    id: 5,
    title: "South Action",
    type: "movie",
    rating: 8.9,
    year: 2023,
    genre: "Action",
    language: "Telugu",
    image: "/placeholder.svg?height=400&width=300&text=South+Movie",
    isPremium: true,
  },
  {
    id: 6,
    title: "Romantic Drama",
    type: "movie",
    rating: 7.5,
    year: 2023,
    genre: "Romance",
    language: "Hindi",
    image: "/placeholder.svg?height=400&width=300&text=Romance",
    isPremium: false,
  },
]

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filteredContent, setFilteredContent] = useState(allContent)
  const [selectedType, setSelectedType] = useState("all")
  const [selectedGenre, setSelectedGenre] = useState("all")
  const [selectedLanguage, setSelectedLanguage] = useState("all")
  const [selectedYear, setSelectedYear] = useState("all")
  const [ratingRange, setRatingRange] = useState([0, 10])
  const [sortBy, setSortBy] = useState("latest")
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    let filtered = allContent

    // Search by title
    if (searchQuery) {
      filtered = filtered.filter((item) => item.title.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    // Filter by type
    if (selectedType !== "all") {
      filtered = filtered.filter((item) => item.type === selectedType)
    }

    // Filter by genre
    if (selectedGenre !== "all") {
      filtered = filtered.filter((item) => item.genre.toLowerCase() === selectedGenre)
    }

    // Filter by language
    if (selectedLanguage !== "all") {
      filtered = filtered.filter((item) => item.language === selectedLanguage)
    }

    // Filter by year
    if (selectedYear !== "all") {
      filtered = filtered.filter((item) => item.year.toString() === selectedYear)
    }

    // Filter by rating
    filtered = filtered.filter((item) => item.rating >= ratingRange[0] && item.rating <= ratingRange[1])

    // Sort results
    switch (sortBy) {
      case "rating":
        filtered.sort((a, b) => b.rating - a.rating)
        break
      case "year":
        filtered.sort((a, b) => b.year - a.year)
        break
      case "title":
        filtered.sort((a, b) => a.title.localeCompare(b.title))
        break
      default:
        filtered.sort((a, b) => b.year - a.year)
    }

    setFilteredContent(filtered)
  }, [searchQuery, selectedType, selectedGenre, selectedLanguage, selectedYear, ratingRange, sortBy])

  const clearFilters = () => {
    setSelectedType("all")
    setSelectedGenre("all")
    setSelectedLanguage("all")
    setSelectedYear("all")
    setRatingRange([0, 10])
    setSortBy("latest")
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="border-b border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <h1 className="text-2xl font-bold text-red-500">StreamMax</h1>
            </Link>
            <Link href="/">
              <Button variant="ghost">← Back to Home</Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <Input
            placeholder="Search movies, web series, actors..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 h-12 text-lg bg-gray-800 border-gray-700 text-white placeholder-gray-400"
          />
        </div>

        <div className="flex gap-6">
          {/* Filters Sidebar */}
          <div className={`${showFilters ? "block" : "hidden"} md:block w-full md:w-80 space-y-6`}>
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Filters</h3>
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    Clear All
                  </Button>
                </div>

                <div className="space-y-4">
                  {/* Content Type */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">Content Type</label>
                    <Select value={selectedType} onValueChange={setSelectedType}>
                      <SelectTrigger className="bg-gray-700 border-gray-600">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All</SelectItem>
                        <SelectItem value="movie">Movies</SelectItem>
                        <SelectItem value="series">Web Series</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Genre */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">Genre</label>
                    <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                      <SelectTrigger className="bg-gray-700 border-gray-600">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Genres</SelectItem>
                        <SelectItem value="action">Action</SelectItem>
                        <SelectItem value="drama">Drama</SelectItem>
                        <SelectItem value="comedy">Comedy</SelectItem>
                        <SelectItem value="crime">Crime</SelectItem>
                        <SelectItem value="romance">Romance</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Language */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">Language</label>
                    <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                      <SelectTrigger className="bg-gray-700 border-gray-600">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Languages</SelectItem>
                        <SelectItem value="Hindi">Hindi</SelectItem>
                        <SelectItem value="English">English</SelectItem>
                        <SelectItem value="Telugu">Telugu</SelectItem>
                        <SelectItem value="Tamil">Tamil</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Year */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">Release Year</label>
                    <Select value={selectedYear} onValueChange={setSelectedYear}>
                      <SelectTrigger className="bg-gray-700 border-gray-600">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Years</SelectItem>
                        <SelectItem value="2024">2024</SelectItem>
                        <SelectItem value="2023">2023</SelectItem>
                        <SelectItem value="2022">2022</SelectItem>
                        <SelectItem value="2021">2021</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Rating Range */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      Rating: {ratingRange[0]} - {ratingRange[1]}
                    </label>
                    <Slider
                      value={ratingRange}
                      onValueChange={setRatingRange}
                      max={10}
                      min={0}
                      step={0.1}
                      className="w-full"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results */}
          <div className="flex-1">
            {/* Results Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <h2 className="text-xl font-semibold">
                  {searchQuery ? `Results for "${searchQuery}"` : "All Content"} ({filteredContent.length})
                </h2>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowFilters(!showFilters)}
                  className="md:hidden border-gray-600 bg-transparent"
                >
                  <Filter className="h-4 w-4 mr-2" />
                  Filters
                </Button>
              </div>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-40 bg-gray-800 border-gray-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="latest">Latest</SelectItem>
                  <SelectItem value="rating">Top Rated</SelectItem>
                  <SelectItem value="year">Release Year</SelectItem>
                  <SelectItem value="title">A-Z</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Results Grid */}
            {filteredContent.length === 0 ? (
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="text-center py-12">
                  <Search className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No Results Found</h3>
                  <p className="text-gray-400 mb-4">Try adjusting your search or filters</p>
                  <Button onClick={clearFilters} variant="outline">
                    Clear Filters
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {filteredContent.map((item) => (
                  <Card
                    key={item.id}
                    className="bg-gray-800 border-gray-700 overflow-hidden group cursor-pointer hover:scale-105 transition-transform"
                  >
                    <div className="relative">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.title}
                        className="w-full h-48 object-cover"
                      />
                      {item.isPremium && (
                        <Badge className="absolute top-2 left-2 bg-yellow-600 text-black text-xs">Premium</Badge>
                      )}
                      <div className="absolute top-2 right-2 bg-yellow-600 text-black px-2 py-1 rounded text-xs font-bold">
                        <Star className="h-3 w-3 fill-current inline mr-1" />
                        {item.rating}
                      </div>
                      {item.type === "series" && (
                        <div className="absolute bottom-2 left-2 bg-black/70 px-2 py-1 rounded text-xs">
                          {item.episodes} Episodes
                        </div>
                      )}
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <Link href={item.type === "movie" ? `/movie/${item.id}` : `/series/${item.id}`}>
                          <Button size="sm" className="bg-red-600 hover:bg-red-700">
                            <Play className="h-4 w-4" />
                          </Button>
                        </Link>
                        <Button size="sm" variant="outline">
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <CardContent className="p-3">
                      <h4 className="font-medium text-sm mb-1 truncate">{item.title}</h4>
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>{item.year}</span>
                        <span>{item.language}</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1 capitalize">{item.genre}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
