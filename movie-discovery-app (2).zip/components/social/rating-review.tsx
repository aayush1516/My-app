"use client"

import { useState, useEffect } from "react"
import { Star, ThumbsUp, ThumbsDown, MessageCircle, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

interface Review {
  id: string
  userId: string
  userName: string
  rating: number
  comment: string
  timestamp: string
  likes: number
  dislikes: number
  userReaction?: "like" | "dislike"
}

interface RatingReviewProps {
  contentId: string
  contentType: "movie" | "series"
  contentTitle: string
}

export function RatingReview({ contentId, contentType, contentTitle }: RatingReviewProps) {
  const [reviews, setReviews] = useState<Review[]>([])
  const [userRating, setUserRating] = useState(0)
  const [userReview, setUserReview] = useState("")
  const [averageRating, setAverageRating] = useState(0)
  const [totalReviews, setTotalReviews] = useState(0)
  const [showReviewForm, setShowReviewForm] = useState(false)

  useEffect(() => {
    // Load reviews from localStorage
    const savedReviews = JSON.parse(localStorage.getItem(`reviews_${contentId}`) || "[]")
    setReviews(savedReviews)

    if (savedReviews.length > 0) {
      const avg = savedReviews.reduce((sum: number, review: Review) => sum + review.rating, 0) / savedReviews.length
      setAverageRating(Number(avg.toFixed(1)))
      setTotalReviews(savedReviews.length)
    }

    // Check if user already reviewed
    const user = JSON.parse(localStorage.getItem("user") || "{}")
    if (user.id) {
      const userExistingReview = savedReviews.find((r: Review) => r.userId === user.id.toString())
      if (userExistingReview) {
        setUserRating(userExistingReview.rating)
        setUserReview(userExistingReview.comment)
      }
    }
  }, [contentId])

  const submitReview = () => {
    const user = JSON.parse(localStorage.getItem("user") || "{}")
    if (!user.id) {
      alert("Please login to submit a review")
      return
    }

    if (userRating === 0) {
      alert("Please select a rating")
      return
    }

    const newReview: Review = {
      id: Date.now().toString(),
      userId: user.id.toString(),
      userName: user.name || "Anonymous",
      rating: userRating,
      comment: userReview,
      timestamp: new Date().toISOString(),
      likes: 0,
      dislikes: 0,
    }

    // Check if user already reviewed
    const existingReviewIndex = reviews.findIndex((r) => r.userId === user.id.toString())
    let updatedReviews

    if (existingReviewIndex >= 0) {
      // Update existing review
      updatedReviews = [...reviews]
      updatedReviews[existingReviewIndex] = { ...updatedReviews[existingReviewIndex], ...newReview }
    } else {
      // Add new review
      updatedReviews = [newReview, ...reviews]
    }

    setReviews(updatedReviews)
    localStorage.setItem(`reviews_${contentId}`, JSON.stringify(updatedReviews))

    // Update average rating
    const avg = updatedReviews.reduce((sum, review) => sum + review.rating, 0) / updatedReviews.length
    setAverageRating(Number(avg.toFixed(1)))
    setTotalReviews(updatedReviews.length)

    setShowReviewForm(false)
    alert("Review submitted successfully!")
  }

  const handleReaction = (reviewId: string, reaction: "like" | "dislike") => {
    const updatedReviews = reviews.map((review) => {
      if (review.id === reviewId) {
        const newReview = { ...review }

        // Remove previous reaction
        if (review.userReaction === "like") {
          newReview.likes--
        } else if (review.userReaction === "dislike") {
          newReview.dislikes--
        }

        // Add new reaction
        if (reaction === "like" && review.userReaction !== "like") {
          newReview.likes++
          newReview.userReaction = "like"
        } else if (reaction === "dislike" && review.userReaction !== "dislike") {
          newReview.dislikes++
          newReview.userReaction = "dislike"
        } else {
          // Remove reaction if clicking same button
          newReview.userReaction = undefined
        }

        return newReview
      }
      return review
    })

    setReviews(updatedReviews)
    localStorage.setItem(`reviews_${contentId}`, JSON.stringify(updatedReviews))
  }

  const StarRating = ({ rating, onRatingChange, readonly = false }: any) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => !readonly && onRatingChange && onRatingChange(star)}
            className={`${readonly ? "cursor-default" : "cursor-pointer hover:scale-110"} transition-transform`}
            disabled={readonly}
          >
            <Star className={`h-5 w-5 ${star <= rating ? "text-yellow-500 fill-current" : "text-gray-400"}`} />
          </button>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Rating Summary */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5" />
            Ratings & Reviews
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-6 mb-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-500">{averageRating}</div>
              <StarRating rating={Math.round(averageRating)} readonly />
              <div className="text-sm text-gray-400 mt-1">{totalReviews} reviews</div>
            </div>
            <div className="flex-1">
              {[5, 4, 3, 2, 1].map((stars) => {
                const count = reviews.filter((r) => r.rating === stars).length
                const percentage = totalReviews > 0 ? (count / totalReviews) * 100 : 0
                return (
                  <div key={stars} className="flex items-center gap-2 mb-1">
                    <span className="text-sm w-8">{stars}★</span>
                    <div className="flex-1 bg-gray-700 rounded-full h-2">
                      <div className="bg-yellow-500 h-2 rounded-full" style={{ width: `${percentage}%` }} />
                    </div>
                    <span className="text-sm text-gray-400 w-8">{count}</span>
                  </div>
                )
              })}
            </div>
          </div>

          <Button onClick={() => setShowReviewForm(!showReviewForm)} className="bg-red-600 hover:bg-red-700">
            Write a Review
          </Button>
        </CardContent>
      </Card>

      {/* Review Form */}
      {showReviewForm && (
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Write Your Review</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Your Rating</label>
              <StarRating rating={userRating} onRatingChange={setUserRating} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Your Review (Optional)</label>
              <Textarea
                placeholder={`Share your thoughts about ${contentTitle}...`}
                value={userReview}
                onChange={(e) => setUserReview(e.target.value)}
                className="bg-gray-700 border-gray-600"
                rows={4}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={submitReview} className="bg-red-600 hover:bg-red-700">
                <Send className="h-4 w-4 mr-2" />
                Submit Review
              </Button>
              <Button variant="outline" onClick={() => setShowReviewForm(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Reviews List */}
      <div className="space-y-4">
        {reviews.map((review) => (
          <Card key={review.id} className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Avatar>
                  <AvatarFallback>{review.userName.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-medium">{review.userName}</span>
                    <StarRating rating={review.rating} readonly />
                    <span className="text-sm text-gray-400">{new Date(review.timestamp).toLocaleDateString()}</span>
                  </div>
                  {review.comment && <p className="text-gray-300 mb-3">{review.comment}</p>}
                  <div className="flex items-center gap-4">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleReaction(review.id, "like")}
                      className={`${
                        review.userReaction === "like" ? "text-green-500" : "text-gray-400"
                      } hover:text-green-500`}
                    >
                      <ThumbsUp className="h-4 w-4 mr-1" />
                      {review.likes}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleReaction(review.id, "dislike")}
                      className={`${
                        review.userReaction === "dislike" ? "text-red-500" : "text-gray-400"
                      } hover:text-red-500`}
                    >
                      <ThumbsDown className="h-4 w-4 mr-1" />
                      {review.dislikes}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
