"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { X, Play } from "lucide-react"
import Image from "next/image"

interface InterstitialAdProps {
  onClose: () => void
}

export function InterstitialAd({ onClose }: InterstitialAdProps) {
  const [countdown, setCountdown] = useState(5)
  const [canClose, setCanClose] = useState(false)

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          setCanClose(true)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardContent className="p-0 relative">
          {/* Close Button */}
          {canClose && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="absolute top-2 right-2 z-10 bg-black/50 text-white hover:bg-black/70"
            >
              <X className="h-5 w-5" />
            </Button>
          )}

          {/* Countdown */}
          {!canClose && (
            <div className="absolute top-2 right-2 z-10 bg-black/70 text-white px-3 py-1 rounded-full text-sm">
              Ad ends in {countdown}s
            </div>
          )}

          {/* Ad Content */}
          <div className="relative aspect-video">
            <Image
              src="/placeholder.svg?height=400&width=600&text=Premium+Movie+Streaming+Ad"
              alt="Advertisement"
              fill
              className="object-cover rounded-lg"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-lg" />

            {/* Ad Text Overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
              <h2 className="text-2xl font-bold mb-2">Upgrade to Premium</h2>
              <p className="text-lg mb-4">
                Enjoy unlimited movies and series without ads. Start your free trial today!
              </p>
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                <Play className="h-5 w-5 mr-2" />
                Start Free Trial
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
