"use client"

import { useState, useEffect } from "react"
import { Gift, Play, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { useAdManager } from "./ad-manager"

interface RewardedAdProps {
  onRewardEarned: () => void
  onClose: () => void
  rewardType: "download" | "premium_content" | "coins"
  rewardAmount?: string
}

const rewardedAds = [
  {
    id: 1,
    title: "Earn Free Download",
    description: "Watch this short video to unlock your download",
    videoUrl: "/placeholder.svg?height=300&width=400&text=Rewarded+Video",
    duration: 30,
    reward: "1 Free Download",
  },
]

export function RewardedAd({ onRewardEarned, onClose, rewardType, rewardAmount }: RewardedAdProps) {
  const { shouldShowAd } = useAdManager()
  const [currentAd] = useState(rewardedAds[0])
  const [timeLeft, setTimeLeft] = useState(currentAd.duration)
  const [isWatching, setIsWatching] = useState(false)
  const [rewardEarned, setRewardEarned] = useState(false)

  useEffect(() => {
    if (!shouldShowAd("downloadRewarded")) {
      onClose()
      return
    }
  }, [shouldShowAd, onClose])

  useEffect(() => {
    if (!isWatching) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setRewardEarned(true)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [isWatching])

  const startWatching = () => {
    setIsWatching(true)
  }

  const claimReward = () => {
    // Track rewarded ad completion
    const rewardedViews = JSON.parse(localStorage.getItem("rewardedAdViews") || "0")
    localStorage.setItem("rewardedAdViews", JSON.stringify(rewardedViews + 1))

    onRewardEarned()
    onClose()
  }

  const progress = ((currentAd.duration - timeLeft) / currentAd.duration) * 100

  const getRewardText = () => {
    switch (rewardType) {
      case "download":
        return rewardAmount || "1 Free Download"
      case "premium_content":
        return rewardAmount || "24h Premium Access"
      case "coins":
        return rewardAmount || "100 StreamCoins"
      default:
        return "Reward"
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center">
      <div className="bg-gray-900 rounded-lg p-6 max-w-md w-full mx-4">
        {!isWatching ? (
          // Pre-watch screen
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Gift className="h-10 w-10 text-white" />
            </div>

            <h2 className="text-2xl font-bold mb-2">Earn Your Reward!</h2>
            <p className="text-gray-400 mb-4">{currentAd.description}</p>

            <div className="bg-gray-800 rounded-lg p-4 mb-6">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Gift className="h-5 w-5 text-yellow-500" />
                <span className="font-semibold text-yellow-500">{getRewardText()}</span>
              </div>
              <p className="text-sm text-gray-400">Watch a {currentAd.duration}s video to earn this reward</p>
            </div>

            <div className="flex gap-3">
              <Button onClick={startWatching} className="flex-1 bg-green-600 hover:bg-green-700">
                <Play className="h-4 w-4 mr-2" />
                Start Video
              </Button>
              <Button onClick={onClose} variant="outline" className="border-gray-600 bg-transparent">
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          // Video watching screen
          <div>
            <div className="relative mb-4">
              <img
                src={currentAd.videoUrl || "/placeholder.svg"}
                alt={currentAd.title}
                className="w-full h-48 object-cover rounded-lg"
              />

              {!rewardEarned && (
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center rounded-lg">
                  <div className="text-center text-white">
                    <Play className="h-12 w-12 mx-auto mb-2" />
                    <p className="text-lg font-semibold">Video Playing...</p>
                    <p className="text-sm">Please wait {timeLeft}s</p>
                  </div>
                </div>
              )}

              {rewardEarned && (
                <div className="absolute inset-0 bg-green-600/80 flex items-center justify-center rounded-lg">
                  <div className="text-center text-white">
                    <Gift className="h-12 w-12 mx-auto mb-2" />
                    <p className="text-lg font-semibold">Reward Earned!</p>
                  </div>
                </div>
              )}

              <div className="absolute top-2 right-2 bg-black/70 px-2 py-1 rounded text-white text-sm">
                {rewardEarned ? "Complete!" : `${timeLeft}s`}
              </div>
            </div>

            <Progress value={progress} className="mb-4" />

            <div className="text-center mb-4">
              <h3 className="font-semibold mb-1">{currentAd.title}</h3>
              <p className="text-sm text-gray-400">
                {rewardEarned
                  ? "Video completed! Claim your reward below."
                  : `Keep watching to earn: ${getRewardText()}`}
              </p>
            </div>

            {rewardEarned ? (
              <Button onClick={claimReward} className="w-full bg-green-600 hover:bg-green-700">
                <Gift className="h-4 w-4 mr-2" />
                Claim {getRewardText()}
              </Button>
            ) : (
              <Button disabled className="w-full bg-gray-600">
                <Play className="h-4 w-4 mr-2" />
                Watching... {timeLeft}s remaining
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
