"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { X, ExternalLink } from "lucide-react"
import Image from "next/image"

const adData = [
  {
    id: 1,
    title: "Premium Gaming Headset",
    description: "Experience crystal clear audio with our latest gaming headset. 50% off for limited time!",
    image: "/placeholder.svg?height=200&width=400&text=Gaming+Headset+Ad",
    cta: "Shop Now",
    url: "#",
  },
  {
    id: 2,
    title: "Stream Anywhere",
    description: "Download our mobile app and watch your favorite movies on the go. Available on iOS and Android.",
    image: "/placeholder.svg?height=200&width=400&text=Mobile+App+Ad",
    cta: "Download App",
    url: "#",
  },
  {
    id: 3,
    title: "Upgrade to Premium",
    description: "Get unlimited access to all content, ad-free streaming, and 4K quality for just $9.99/month.",
    image: "/placeholder.svg?height=200&width=400&text=Premium+Upgrade+Ad",
    cta: "Upgrade Now",
    url: "/plans",
  },
]

export function AdBanner() {
  const [currentAd, setCurrentAd] = useState(0)
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentAd((prev) => (prev + 1) % adData.length)
    }, 10000) // Change ad every 10 seconds

    return () => clearInterval(timer)
  }, [])

  if (!isVisible) return null

  const ad = adData[currentAd]

  return (
    <div className="container mx-auto px-4 py-4">
      <Card className="relative overflow-hidden bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
        <CardContent className="p-0">
          <div className="flex flex-col md:flex-row items-center">
            {/* Ad Image */}
            <div className="relative w-full md:w-1/3 h-48 md:h-32">
              <Image src={ad.image || "/placeholder.svg"} alt={ad.title} fill className="object-cover" />
            </div>

            {/* Ad Content */}
            <div className="flex-1 p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-bold mb-2">{ad.title}</h3>
                  <p className="text-muted-foreground mb-4 text-sm">{ad.description}</p>
                  <Button size="sm" className="bg-primary hover:bg-primary/90">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    {ad.cta}
                  </Button>
                </div>

                {/* Close Button */}
                <Button variant="ghost" size="icon" onClick={() => setIsVisible(false)} className="ml-4 h-8 w-8">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Ad Indicators */}
          <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {adData.map((_, index) => (
              <button
                key={index}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentAd ? "bg-primary" : "bg-primary/30"
                }`}
                onClick={() => setCurrentAd(index)}
              />
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
