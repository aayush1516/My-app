"use client"

import { useState, useEffect } from "react"
import { X, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAdManager } from "./ad-manager"

interface BannerAdProps {
  position: "top" | "bottom" | "middle"
  size?: "small" | "medium" | "large"
}

const adContent = [
  {
    id: 1,
    title: "🎬 Upgrade to Premium",
    description: "Starting at just ₹153/month - Remove all ads and enjoy unlimited downloads",
    image: "/placeholder.svg?height=100&width=300&text=Premium+Ad",
    cta: "Upgrade Now",
    link: "/plans",
    bgColor: "from-purple-600 to-blue-600",
  },
  {
    id: 2,
    title: "📱 Download Our App",
    description: "Get the best streaming experience on mobile",
    image: "/placeholder.svg?height=100&width=300&text=Mobile+App",
    cta: "Download",
    link: "#",
    bgColor: "from-green-600 to-teal-600",
  },
  {
    id: 3,
    title: "🔥 New Movies Added",
    description: "Check out the latest blockbusters now available",
    image: "/placeholder.svg?height=100&width=300&text=New+Movies",
    cta: "Watch Now",
    link: "/",
    bgColor: "from-red-600 to-pink-600",
  },
  {
    id: 4,
    title: "💰 Special Offer - Save 58%",
    description: "Yearly plan at ₹1,530 - Limited time offer",
    image: "/placeholder.svg?height=100&width=300&text=58%+OFF",
    cta: "Claim Offer",
    link: "/plans",
    bgColor: "from-yellow-600 to-orange-600",
  },
]

export function BannerAd({ position, size = "medium" }: BannerAdProps) {
  const { shouldShowAd } = useAdManager()
  const [currentAd, setCurrentAd] = useState(adContent[0])
  const [isVisible, setIsVisible] = useState(true)
  const [adClicks, setAdClicks] = useState(0)

  useEffect(() => {
    if (!shouldShowAd("topBanner")) {
      setIsVisible(false)
      return
    }

    // Rotate ads every 10 seconds
    const interval = setInterval(() => {
      setCurrentAd(adContent[Math.floor(Math.random() * adContent.length)])
    }, 10000)

    return () => clearInterval(interval)
  }, [shouldShowAd])

  const handleAdClick = () => {
    setAdClicks((prev) => prev + 1)

    // Track ad clicks
    const clicks = JSON.parse(localStorage.getItem("adClicks") || "0")
    localStorage.setItem("adClicks", JSON.stringify(clicks + 1))

    // Open link
    if (currentAd.link.startsWith("http")) {
      window.open(currentAd.link, "_blank")
    } else {
      window.location.href = currentAd.link
    }
  }

  const getSizeClasses = () => {
    switch (size) {
      case "small":
        return "h-16 text-sm"
      case "large":
        return "h-32 text-lg"
      default:
        return "h-24 text-base"
    }
  }

  if (!isVisible || !shouldShowAd("topBanner")) {
    return null
  }

  return (
    <div className={`relative w-full ${getSizeClasses()} overflow-hidden`}>
      <div
        className={`w-full h-full bg-gradient-to-r ${currentAd.bgColor} flex items-center justify-between px-6 cursor-pointer hover:opacity-90 transition-opacity`}
        onClick={handleAdClick}
      >
        <div className="flex items-center gap-4">
          <img
            src={currentAd.image || "/placeholder.svg"}
            alt={currentAd.title}
            className="h-12 w-12 rounded object-cover"
          />
          <div className="text-white">
            <h3 className="font-bold">{currentAd.title}</h3>
            <p className="text-sm opacity-90">{currentAd.description}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30">
            {currentAd.cta}
            <ExternalLink className="h-4 w-4 ml-2" />
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation()
              setIsVisible(false)
            }}
            className="text-white hover:bg-white/20"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Ad indicator */}
      <div className="absolute bottom-1 left-2 text-xs text-white/70 bg-black/30 px-2 py-1 rounded">
        Ad • Clicks: {adClicks}
      </div>
    </div>
  )
}
