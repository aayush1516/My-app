"use client"

import { useEffect, useState } from "react"

interface AdConfig {
  enabled: boolean
  type: "banner" | "interstitial" | "rewarded" | "native"
  position: string
  frequency: number
  showForFreeUsers: boolean
  showForPremiumUsers: boolean
}

const defaultAdConfig: Record<string, AdConfig> = {
  topBanner: {
    enabled: true,
    type: "banner",
    position: "top",
    frequency: 1,
    showForFreeUsers: true,
    showForPremiumUsers: false,
  },
  homeBanner: {
    enabled: true,
    type: "banner",
    position: "home_middle",
    frequency: 1,
    showForFreeUsers: true,
    showForPremiumUsers: false,
  },
  videoInterstitial: {
    enabled: true,
    type: "interstitial",
    position: "before_video",
    frequency: 1,
    showForFreeUsers: true,
    showForPremiumUsers: false,
  },
  downloadRewarded: {
    enabled: true,
    type: "rewarded",
    position: "download_unlock",
    frequency: 1,
    showForFreeUsers: true,
    showForPremiumUsers: false,
  },
  sidebarNative: {
    enabled: true,
    type: "native",
    position: "sidebar",
    frequency: 3,
    showForFreeUsers: true,
    showForPremiumUsers: false,
  },
}

export function useAdManager() {
  const [adConfig, setAdConfig] = useState(defaultAdConfig)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    // Load user data
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }

    // Load ad configuration
    const savedConfig = localStorage.getItem("adConfig")
    if (savedConfig) {
      setAdConfig(JSON.parse(savedConfig))
    } else {
      localStorage.setItem("adConfig", JSON.stringify(defaultAdConfig))
    }
  }, [])

  const shouldShowAd = (adType: string): boolean => {
    const config = adConfig[adType]
    if (!config || !config.enabled) return false

    const isPremium = user?.plan === "premium"

    if (isPremium && !config.showForPremiumUsers) return false
    if (!isPremium && !config.showForFreeUsers) return false

    return true
  }

  const updateAdConfig = (adType: string, newConfig: Partial<AdConfig>) => {
    const updatedConfig = {
      ...adConfig,
      [adType]: { ...adConfig[adType], ...newConfig },
    }
    setAdConfig(updatedConfig)
    localStorage.setItem("adConfig", JSON.stringify(updatedConfig))
  }

  return { shouldShowAd, updateAdConfig, adConfig, user }
}
