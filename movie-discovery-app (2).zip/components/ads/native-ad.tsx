"use client"

import { useState, useEffect } from "react"
import { ExternalLink, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useAdManager } from "./ad-manager"

interface NativeAdProps {
  position: "sidebar" | "content" | "footer"
  style?: "card" | "inline" | "minimal"
}

const nativeAds = [
  {
    id: 1,
    title: "StreamMax Premium",
    description: "Starting at ₹153/month - Unlock unlimited movies, web series, and ad-free streaming",
    image: "/placeholder.svg?height=200&width=300&text=Premium+Features",
    rating: 4.8,
    reviews: "10K+ reviews",
    cta: "Try Premium ₹153",
    link: "/plans",
    sponsored: true,
    category: "Entertainment",
  },
  {
    id: 2,
    title: "Yearly Plan - Save 58%",
    description: "Get Premium for ₹1,530/year - Best value for unlimited entertainment",
    image: "/placeholder.svg?height=200&width=300&text=Yearly+Plan",
    rating: 4.9,
    reviews: "15K+ subscribers",
    cta: "Save ₹2,070",
    link: "/plans",
    sponsored: true,
    category: "Offer",
  },
]

export function NativeAd({ position, style = "card" }: NativeAdProps) {
  const { shouldShowAd } = useAdManager()
  const [currentAd, setCurrentAd] = useState(nativeAds[0])
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    if (!shouldShowAd("sidebarNative")) {
      setIsVisible(false)
      return
    }

    // Rotate native ads every 30 seconds
    const interval = setInterval(() => {
      setCurrentAd(nativeAds[Math.floor(Math.random() * nativeAds.length)])
    }, 30000)

    return () => clearInterval(interval)
  }, [shouldShowAd])

  const handleAdClick = () => {
    // Track native ad clicks
    const nativeClicks = JSON.parse(localStorage.getItem("nativeAdClicks") || "0")
    localStorage.setItem("nativeAdClicks", JSON.stringify(nativeClicks + 1))

    if (currentAd.link.startsWith("http")) {
      window.open(currentAd.link, "_blank")
    } else {
      window.location.href = currentAd.link
    }
  }

  if (!isVisible || !shouldShowAd("sidebarNative")) {
    return null
  }

  if (style === "minimal") {
    return (
      <div className="p-4 bg-gray-800 rounded-lg border border-gray-700">
        <div className="flex items-center gap-3 cursor-pointer" onClick={handleAdClick}>
          <img
            src={currentAd.image || "/placeholder.svg"}
            alt={currentAd.title}
            className="w-12 h-12 rounded object-cover"
          />
          <div className="flex-1">
            <h4 className="font-medium text-sm">{currentAd.title}</h4>
            <p className="text-xs text-gray-400">{currentAd.category}</p>
          </div>
          <Badge variant="secondary" className="text-xs">
            Sponsored
          </Badge>
        </div>
      </div>
    )
  }

  if (style === "inline") {
    return (
      <div
        className="flex items-center gap-4 p-4 bg-gray-800 rounded-lg border border-gray-700 cursor-pointer hover:bg-gray-700 transition-colors"
        onClick={handleAdClick}
      >
        <img
          src={currentAd.image || "/placeholder.svg"}
          alt={currentAd.title}
          className="w-16 h-16 rounded object-cover"
        />
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h4 className="font-medium">{currentAd.title}</h4>
            <Badge variant="secondary" className="text-xs">
              Sponsored
            </Badge>
          </div>
          <p className="text-sm text-gray-400 mb-2">{currentAd.description}</p>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 text-yellow-500 fill-current" />
              <span className="text-sm">{currentAd.rating}</span>
            </div>
            <span className="text-sm text-gray-500">•</span>
            <span className="text-sm text-gray-500">{currentAd.reviews}</span>
          </div>
        </div>
        <Button size="sm" className="bg-red-600 hover:bg-red-700">
          {currentAd.cta}
          <ExternalLink className="h-4 w-4 ml-2" />
        </Button>
      </div>
    )
  }

  // Default card style
  return (
    <Card
      className="bg-gray-800 border-gray-700 overflow-hidden cursor-pointer hover:bg-gray-750 transition-colors"
      onClick={handleAdClick}
    >
      <div className="relative">
        <img src={currentAd.image || "/placeholder.svg"} alt={currentAd.title} className="w-full h-48 object-cover" />
        <Badge className="absolute top-2 right-2 bg-yellow-600 text-black text-xs">Sponsored</Badge>
      </div>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <h3 className="font-semibold text-lg">{currentAd.title}</h3>
        </div>
        <p className="text-gray-400 text-sm mb-3 line-clamp-2">{currentAd.description}</p>

        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 text-yellow-500 fill-current" />
              <span className="text-sm font-medium">{currentAd.rating}</span>
            </div>
            <span className="text-sm text-gray-500">({currentAd.reviews})</span>
          </div>
          <Badge variant="outline" className="text-xs">
            {currentAd.category}
          </Badge>
        </div>

        <Button className="w-full bg-red-600 hover:bg-red-700">
          {currentAd.cta}
          <ExternalLink className="h-4 w-4 ml-2" />
        </Button>
      </CardContent>
    </Card>
  )
}
