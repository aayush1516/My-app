"use client"

import { useState } from "react"
import { Star, Play, Plus, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface MovieCardProps {
  movie: {
    id: number
    title: string
    rating: number
    year: number
    genre: string
    image: string
    description?: string
  }
  variant?: "grid" | "list"
}

export function MovieCard({ movie, variant = "grid" }: MovieCardProps) {
  const [isFavorite, setIsFavorite] = useState(false)

  if (variant === "list") {
    return (
      <Card className="bg-gray-800 border-gray-700 overflow-hidden">
        <div className="flex">
          <img src={movie.image || "/placeholder.svg"} alt={movie.title} className="w-24 h-36 object-cover" />
          <CardContent className="flex-1 p-4">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-semibold text-lg mb-1">{movie.title}</h3>
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <span>{movie.year}</span>
                  <span>•</span>
                  <span>{movie.genre}</span>
                </div>
              </div>
              <div className="flex items-center gap-1 bg-yellow-600 px-2 py-1 rounded">
                <Star className="h-3 w-3 fill-current" />
                <span className="text-xs font-medium">{movie.rating}</span>
              </div>
            </div>
            {movie.description && <p className="text-sm text-gray-300 mb-3 line-clamp-2">{movie.description}</p>}
            <div className="flex gap-2">
              <Button size="sm" className="bg-red-600 hover:bg-red-700">
                <Play className="h-4 w-4 mr-1" />
                Watch
              </Button>
              <Button size="sm" variant="outline" className="border-gray-600 bg-transparent">
                <Plus className="h-4 w-4 mr-1" />
                Watchlist
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setIsFavorite(!isFavorite)}
                className={isFavorite ? "text-red-500" : "text-gray-400"}
              >
                <Heart className={`h-4 w-4 ${isFavorite ? "fill-current" : ""}`} />
              </Button>
            </div>
          </CardContent>
        </div>
      </Card>
    )
  }

  return (
    <Card className="bg-gray-800 border-gray-700 overflow-hidden group cursor-pointer hover:scale-105 transition-transform">
      <div className="relative">
        <img src={movie.image || "/placeholder.svg"} alt={movie.title} className="w-full h-48 object-cover" />
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <Button size="sm" className="bg-red-600 hover:bg-red-700">
            <Play className="h-4 w-4" />
          </Button>
        </div>
        <div className="absolute top-2 right-2">
          <Badge variant="secondary" className="bg-yellow-600 text-black">
            <Star className="h-3 w-3 fill-current mr-1" />
            {movie.rating}
          </Badge>
        </div>
        <button
          onClick={() => setIsFavorite(!isFavorite)}
          className={`absolute top-2 left-2 p-1 rounded-full bg-black/50 ${isFavorite ? "text-red-500" : "text-white"}`}
        >
          <Heart className={`h-4 w-4 ${isFavorite ? "fill-current" : ""}`} />
        </button>
      </div>
      <CardContent className="p-3">
        <h3 className="font-medium text-sm mb-1 line-clamp-2">{movie.title}</h3>
        <div className="flex items-center gap-1 text-xs text-gray-400">
          <span>{movie.year}</span>
          <span>•</span>
          <span className="truncate">{movie.genre}</span>
        </div>
      </CardContent>
    </Card>
  )
}
